import { run, get, query, createAuditLog } from './db.js';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import path from 'path';
import { resolveJwtSecret } from './shared/infrastructure/config.js';
import { assertSessionAccess, AuthorizationError } from './modules/identity/application/policies.js';
import { resolveValidationMode, DomainValidationError } from './modules/attendance/domain/validationMode.js';
import { calculateAttendanceBlocks as calculateAttendanceBlocksDomain } from './modules/attendance/domain/punctuality.js';
import { QR_WINDOW_MS, getAllowedQrOffsetsMs, matchToken as matchTokenDomain } from './modules/attendance/domain/qrRotation.js';
import { parseDataUrlOrBase64, validateEvidencePayload } from './modules/attendance/domain/evidenceValidation.js';
import { isWithinBusinessDaysPure } from './modules/excuses/domain/businessDays.js';
import { computeHmacQrToken, decodeBase64ToBytes, computeSha256Hex } from './shared/infrastructure/hmac.js';

const JWT_SECRET = resolveJwtSecret();

const isAssignedToUnit = async (instructorId, unitId) => {
  const row = await get(
    'SELECT id FROM instructor_assignments WHERE instructor_id = ? AND unit_id = ?',
    [instructorId, unitId]
  );
  return Boolean(row);
};

const enforceSessionAccess = async (req, res, session) => {
  try {
    await assertSessionAccess(req.user, session, { isAssignedToUnit });
    return true;
  } catch (err) {
    if (err instanceof AuthorizationError) {
      res.status(err.status).json({ error: { code: err.code, message: err.message } });
      return false;
    }
    throw err;
  }
};

// Helper to sanitize text and prevent script injection
export const sanitizeText = (str, maxLength = 255) => {
  if (!str || typeof str !== 'string') return '';
  return str
    .replace(/[<>]/g, '')
    .trim()
    .substring(0, maxLength);
};

// Helper to sanitize document identifiers
export const sanitizeDocument = (doc) => {
  if (!doc) return '';
  return String(doc).trim().replace(/[^a-zA-Z0-9_-]/g, '').substring(0, 30);
};

// Helper to get client IP
const getClientIp = (req) => {
  const xForwardedFor = req.headers && req.headers['x-forwarded-for'];
  if (xForwardedFor) {
    return xForwardedFor.split(',')[0].trim();
  }
  return req.socket?.remoteAddress || req.ip || '127.0.0.1';
};

// QR Token generator based on BR-03 / ADR-002 (15-second blocks + 1 leeway slot)
export const generateQrToken = (sessionId, timeOffset = 0, nowMs = Date.now()) => {
  return computeHmacQrToken(sessionId, { nowMs, timeOffsetMs: timeOffset });
};

// Match input token dynamically (full 12-char QR token or 6-char manual code)
export const matchToken = matchTokenDomain;

// Re-export pure domain punctuality formula (BR-02)
export { calculateAttendanceBlocksDomain as calculateAttendanceBlocksPure };

// Check if two IPs are on the same subnet or sharing NAT
const checkSameSubnetOrIp = (ip1, ip2) => {
  if (!ip1 || !ip2) return false;
  
  const norm1 = ip1.replace('::ffff:', '').trim();
  const norm2 = ip2.replace('::ffff:', '').trim();
  
  if (norm1 === norm2) return true;
  
  // Both are loopback/local
  const localips = ['127.0.0.1', '::1', 'localhost'];
  if (localips.includes(norm1) && localips.includes(norm2)) {
    return true;
  }
  
  // Subnet /24 check (e.g. 192.168.1.X)
  const parts1 = norm1.split('.');
  const parts2 = norm2.split('.');
  if (parts1.length === 4 && parts2.length === 4) {
    return parts1[0] === parts2[0] && parts1[1] === parts2[1] && parts1[2] === parts2[2];
  }
  
  return false;
};

// Pure function to calculate attendance blocks based on arrival time
export const calculateAttendanceBlocks = (activatedAtStr, arrivalTimeStr, durationHours = 6) => {
  if (!activatedAtStr || !arrivalTimeStr) {
    return { horasAsistidas: durationHours, horasFalla: 0, tipoRegistro: 'REGULAR', status: 'accepted' };
  }
  const activated = new Date(activatedAtStr);
  const arrival = new Date(arrivalTimeStr);
  const diffMs = Math.max(0, arrival.getTime() - activated.getTime());

  // Grace period: exactly 15 minutes (15 * 60 * 1000 ms)
  if (diffMs <= 15 * 60 * 1000) {
    return {
      horasAsistidas: durationHours,
      horasFalla: 0,
      tipoRegistro: 'REGULAR',
      status: 'accepted'
    };
  }

  // Any second past 15 min enters hourly block deduction
  // 15:01 to 60:00 -> 1 block lost
  // 60:01 to 120:00 -> 2 blocks lost
  const blocksLost = Math.min(durationHours, Math.ceil(diffMs / (60 * 60 * 1000)));
  const horasAsistidas = durationHours - blocksLost;

  return {
    horasAsistidas,
    horasFalla: blocksLost,
    tipoRegistro: `RETARDO_BLOQUE_${blocksLost}`,
    status: horasAsistidas === 0 ? 'ASISTENCIA_PARCIAL' : 'ASISTENCIA_PARCIAL'
  };
};

// Deterministic Time & Working Days Calculation (America/Bogota)
export const getBogotaDateString = (dateObj) => {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Bogota',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
  return formatter.format(dateObj);
};

export const calculateBusinessDaysDeadline = async (sessionDateStr, allowedDays = 3) => {
  const sessionDate = new Date(sessionDateStr);
  const holidayRows = await query('SELECT date FROM holidays WHERE active = 1');
  const holidaySet = new Set(holidayRows.map(h => h.date));

  let businessDaysCounted = 0;
  let targetBogotaDateStr = '';

  for (let i = 1; i <= 30; i++) {
    const nextDay = new Date(sessionDate.getTime() + i * 24 * 60 * 60 * 1000);
    const dateStr = getBogotaDateString(nextDay);
    const parts = dateStr.split('-').map(Number);
    const dayOfWeek = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], 12, 0, 0)).getUTCDay();
    const isWeekend = (dayOfWeek === 0 || dayOfWeek === 6);
    const isHoliday = holidaySet.has(dateStr);

    if (!isWeekend && !isHoliday) {
      businessDaysCounted++;
      if (businessDaysCounted === allowedDays) {
        targetBogotaDateStr = dateStr;
        break;
      }
    }
  }

  // End of third business day at 23:59:59.999 America/Bogota (UTC-5)
  return new Date(`${targetBogotaDateStr}T23:59:59.999-05:00`);
};

export const isWithinBusinessDays = async (sessionDateStr, submissionDate = new Date(), allowedDays = 3) => {
  const subDate = new Date(submissionDate);
  const deadline = await calculateBusinessDaysDeadline(sessionDateStr, allowedDays);
  return subDate.getTime() <= deadline.getTime();
};

// Catalog Controllers
export const getInstitutions = async (req, res) => {
  try {
    const rows = await query('SELECT * FROM institutions WHERE active = 1');
    res.json({ data: rows.map(r => ({ ...r, labels: JSON.parse(r.labels), theme: JSON.parse(r.theme) })) });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getUnits = async (req, res) => {
  try {
    const { institutionId } = req.params;
    const rows = await query('SELECT * FROM academic_units WHERE institution_id = ? AND active = 1', [institutionId]);
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getPeople = async (req, res) => {
  try {
    const { unitId } = req.params;
    const rows = await query(`
      SELECT p.id, p.documento, p.nombre, p.matricula, p.roles
      FROM people p
      JOIN enrollments e ON p.id = e.person_id
      WHERE e.unit_id = ? AND e.active = 1 AND p.active = 1
    `, [unitId]);
    res.json({ data: rows.map(r => ({ ...r, roles: JSON.parse(r.roles) })) });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Room Controllers
export const createRoom = async (req, res) => {
  try {
    const { institutionId, unitId, qrTtlMinutes = 15, ipCheckEnabled = true, qrEnabled = true, validationMode } = req.body;
    if (!institutionId || !unitId) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'institutionId y unitId son requeridos.' } });
    }

    let resolvedMode;
    try {
      resolvedMode = resolveValidationMode({ validationMode, ipCheckEnabled, qrEnabled });
    } catch (err) {
      if (err instanceof DomainValidationError) {
        return res.status(err.status).json({ error: { code: err.code, message: err.message } });
      }
      throw err;
    }
    const isIpActive = resolvedMode.ipCheckEnabled;
    const finalMode = resolvedMode.validationMode;

    // Check if unit belongs to institution and contains people
    const unit = await get('SELECT * FROM academic_units WHERE id = ? AND institution_id = ?', [unitId, institutionId]);
    if (!unit) {
      return res.status(400).json({ error: { code: 'UNIT_INSTITUTION_MISMATCH', message: 'Ficha no pertenece a la institución.' } });
    }

    // Check instructor assignment: if user is instructor (and not coordinator), must be assigned to unitId
    const userRoles = req.user?.roles || [];
    const isInstructor = userRoles.includes('INSTRUCTOR') && !userRoles.includes('COORDINADOR');
    if (isInstructor && req.user?.id) {
      const assignment = await get(
        'SELECT id FROM instructor_assignments WHERE instructor_id = ? AND unit_id = ? AND institution_id = ?',
        [req.user.id, unitId, institutionId]
      );
      if (!assignment) {
        return res.status(403).json({
          error: {
            code: 'INSTRUCTOR_NOT_ASSIGNED',
            message: 'No estás asignado a esta ficha. No puedes abrir clase.'
          }
        });
      }
    }

    const countPeople = await get(`
      SELECT COUNT(*) as count FROM enrollments WHERE unit_id = ? AND active = 1
    `, [unitId]);
    if (countPeople.count === 0) {
      return res.status(400).json({ error: { code: 'UNIT_EMPTY', message: 'La ficha no tiene aprendices inscritos.' } });
    }

    const sessionId = `sala_${Date.now()}`;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 15 * 60000); // Strict 15 mins room timer
    const creatorIp = getClientIp(req);
    const ipCheckVal = isIpActive ? 1 : 0;

    await run(`
      INSERT INTO attendance_sessions (
        id, institution_id, unit_id, status, qr_token, qr_expires_at, qr_ttl_minutes,
        activated_at, room_created_at, room_expires_at, is_reopened, creator_ip, ip_check_enabled, validation_mode, created_by
      ) VALUES (?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)
    `, [
      sessionId, institutionId, unitId,
      generateQrToken(sessionId, 0),
      expiresAt.toISOString(),
      qrTtlMinutes,
      now.toISOString(),
      now.toISOString(),
      expiresAt.toISOString(),
      creatorIp,
      ipCheckVal,
      finalMode,
      req.user?.id || 'INSTRUCTOR'
    ]);

    await createAuditLog(req.user?.id, 'CREATE_ROOM', 'session', sessionId, null, { validation_mode: finalMode, unitId }, { creatorIp });

    const createdSession = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    res.status(201).json({ ok: true, data: createdSession });
  } catch (err) {
    console.error('Error creating room:', err);
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const createSessionDraft = async (req, res) => {
  // Alias or direct creation
  return createRoom(req, res);
};

export const activateSession = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }
    if (!(await enforceSessionAccess(req, res, session))) return;

    const now = new Date();
    const expiresAt = new Date(now.getTime() + 15 * 60000);
    const creatorIp = getClientIp(req);

    await run(`
      UPDATE attendance_sessions
      SET status = 'active', activated_at = ?, room_created_at = ?, room_expires_at = ?, is_reopened = 0, creator_ip = ?, qr_token = ?
      WHERE id = ?
    `, [
      now.toISOString(),
      now.toISOString(),
      expiresAt.toISOString(),
      creatorIp,
      generateQrToken(sessionId, 0),
      sessionId
    ]);

    const updated = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    res.json({ data: updated });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const closeSession = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }
    if (!(await enforceSessionAccess(req, res, session))) return;

    const now = new Date();
    await run(`
      UPDATE attendance_sessions
      SET status = 'closed', closed_at = ?
      WHERE id = ?
    `, [now.toISOString(), sessionId]);

    const updated = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    res.json({ data: updated });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const reopenRoom = async (req, res) => {
  try {
    const { sessionId } = req.body;
    if (!sessionId) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'sessionId es requerido.' } });
    }

    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }
    if (!(await enforceSessionAccess(req, res, session))) return;

    const now = new Date();
    const expiresAt = new Date(now.getTime() + 15 * 60000); // 15 mins for checkout
    const creatorIp = getClientIp(req);

    await run(`
      UPDATE attendance_sessions
      SET status = 'active', room_expires_at = ?, is_reopened = 1, creator_ip = ?, qr_token = ?
      WHERE id = ?
    `, [expiresAt.toISOString(), creatorIp, generateQrToken(sessionId, 0), sessionId]);

    const updated = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    res.json({ data: updated, message: 'Sala reabierta para registrar salida.' });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getSession = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }
    
    // Add current rotation token to check
    session.currentQrToken = generateQrToken(sessionId, 0);
    session.qrRotationSec = 60 - Math.floor((Date.now() % 60000) / 1000);

    res.json({ data: session });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getSessionQrToken = async (req, res) => {
  try {
    const { sessionId } = req.params;
    res.json({
      qrToken: generateQrToken(sessionId, 0),
      expiresSec: 60 - Math.floor((Date.now() % 60000) / 1000)
    });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getSessionsHistory = async (req, res) => {
  try {
    const { unit_id, status, startDate, endDate } = req.query || {};
    let sql = 'SELECT * FROM attendance_sessions WHERE 1=1';
    const params = [];

    if (unit_id) {
      sql += ' AND unit_id = ?';
      params.push(sanitizeText(unit_id, 50));
    }
    if (status) {
      sql += ' AND status = ?';
      params.push(sanitizeText(status, 20));
    }
    if (startDate) {
      sql += ' AND room_created_at >= ?';
      params.push(sanitizeText(startDate, 40));
    }
    if (endDate) {
      sql += ' AND room_created_at <= ?';
      params.push(sanitizeText(endDate, 40));
    }

    sql += ' ORDER BY room_created_at DESC LIMIT 100';
    const rows = await query(sql, params);
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Helper to check session state and document existence
export const checkDocument = async (req, res) => {
  try {
    const { documento } = req.body;
    const { token } = req.params;

    const cleanDoc = sanitizeDocument(documento);
    if (!cleanDoc || !token) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Documento válido y token QR son requeridos.' } });
    }

    // Find session (BR-03: 15s window + 1 leeway slot)
    let session = null;
    const activeSessions = await query("SELECT * FROM attendance_sessions WHERE LOWER(status) IN ('active', 'open')");
    const allowedOffsets = getAllowedQrOffsetsMs();
    for (const s of activeSessions) {
      for (const offset of allowedOffsets) {
        const tok = generateQrToken(s.id, offset);
        if (matchToken(token, tok) || (s.qr_token && matchToken(token, s.qr_token))) { session = s; break; }
      }
      if (session) break;
    }

    if (!session) {
      return res.status(400).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada o token QR inválido/vencido.' } });
    }

    if (session.status === 'closed') {
      return res.status(400).json({ error: { code: 'SESSION_CLOSED', message: 'La sala está cerrada por el instructor.' } });
    }

    const now = new Date();
    if (now > new Date(session.room_expires_at)) {
      return res.status(400).json({ error: { code: 'ROOM_EXPIRED', message: 'La ventana de 15 minutos ha cerrado.' } });
    }

    // Check person
    const person = await get('SELECT * FROM people WHERE documento = ? AND active = 1', [cleanDoc]);
    return res.json({
      data: {
        exists: !!person,
        documento: cleanDoc
      }
    });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Check-in logic
export const checkin = async (req, res) => {
  try {
    const { documento, qrToken, sessionId: bodySessionId } = req.body;
    const pathToken = req.params.token; // From GET/POST /public/attendance/:token/register
    const token = qrToken || pathToken;
    const cleanDoc = sanitizeDocument(documento);

    if (!cleanDoc || !token) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Documento y token de QR son requeridos.' } });
    }

    // Find the session that has this token active or find by session id if supplied
    let session;
    if (bodySessionId) {
      session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [bodySessionId]);
    } else {
      // Find session by matching rotating token (BR-03: 15s window + 1 leeway slot)
      const activeSessions = await query("SELECT * FROM attendance_sessions WHERE LOWER(status) IN ('active', 'open')");
      const allowedOffsets = getAllowedQrOffsetsMs();
      for (const s of activeSessions) {
        for (const offset of allowedOffsets) {
          const tok = generateQrToken(s.id, offset);
          if (matchToken(token, tok) || (s.qr_token && matchToken(token, s.qr_token))) {
            session = s;
            break;
          }
        }
        if (session) break;
      }
    }

    if (!session) {
      return res.status(400).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada o token QR inválido/vencido.' } });
    }

    // Validations: Closed Session
    if (session.status === 'closed') {
      return res.status(400).json({ error: { code: 'SESSION_CLOSED', message: 'La sala está cerrada por el instructor.' } });
    }

    // Validations: Room Expiration (15 minutes)
    const now = new Date();
    const roomExpires = new Date(session.room_expires_at);
    if (now > roomExpires) {
      return res.status(400).json({ error: { code: 'ROOM_EXPIRED', message: 'La ventana de 15 minutos ha cerrado. No se admiten registros.' } });
    }

    // Find person
    const person = await get('SELECT * FROM people WHERE documento = ? AND active = 1', [cleanDoc]);
    if (!person) {
      // Record rejected attempt in DB
      await run(`
        INSERT INTO attendance_records (
          id, session_id, institution_id, unit_id, documento, status, reject_reason, message, created_at, client_ip
        ) VALUES (?, ?, ?, ?, ?, 'rejected', 'PERSON_NOT_FOUND', ?, ?, ?)
      `, [`rec_${Date.now()}`, session.id, session.institution_id, session.unit_id, cleanDoc, 'Persona no encontrada en el sistema.', now.toISOString(), getClientIp(req)]);

      return res.status(404).json({ error: { code: 'PERSON_NOT_FOUND', message: 'El aprendiz no está registrado.' } });
    }

    // Check if enrolled in this academic unit (auto-enroll active students)
    let enrollment = await get('SELECT * FROM enrollments WHERE unit_id = ? AND person_id = ? AND active = 1', [session.unit_id, person.id]);
    if (!enrollment) {
      const enrollId = `enr_${person.id}_${session.unit_id}_${Date.now().toString(36)}`;
      await run(`
        INSERT INTO enrollments (id, institution_id, unit_id, person_id, active)
        VALUES (?, ?, ?, ?, 1)
      `, [enrollId, session.institution_id, session.unit_id, person.id]);
    }

    // AUTHENTICATION CHECK: If valid JWT Bearer token supplied for this person, bypass password
    let isAuthenticated = false;
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const jwtToken = authHeader.split(' ')[1];
      try {
        const decoded = jwt.verify(jwtToken, JWT_SECRET);
        if (decoded && (decoded.id === person.id || decoded.documento === person.documento)) {
          isAuthenticated = true;
        }
      } catch (jwtErr) {
        // Fall back to password check
      }
    }

    if (!isAuthenticated) {
      // PASSWORD VALIDATION (for unauthenticated requests)
      const { password } = req.body;
      if (!password) {
        return res.status(400).json({ error: { code: 'PASSWORD_REQUIRED', message: 'La contraseña es requerida para identificar al estudiante.' } });
      }

      let isMatch = false;
      if (person.password.startsWith('$2b$') || person.password.startsWith('$2a$')) {
        isMatch = await bcrypt.compare(password, person.password);
      } else {
        isMatch = (password === person.password);
      }

      if (!isMatch) {
        await run(`
          INSERT INTO attendance_records (
            id, session_id, institution_id, unit_id, person_id, documento, status, reject_reason, message, created_at, client_ip
          ) VALUES (?, ?, ?, ?, ?, ?, 'rejected', 'INVALID_PASSWORD', ?, ?, ?)
        `, [`rec_${Date.now()}`, session.id, session.institution_id, session.unit_id, person.id, documento, 'Contraseña incorrecta.', now.toISOString(), getClientIp(req)]);

        return res.status(401).json({ error: { code: 'INVALID_PASSWORD', message: 'Contraseña incorrecta.' } });
      }
    }

    // SECURITY CHECK: Subnet LAN / Client IP match
    const clientIp = getClientIp(req);
    const creatorIp = session.creator_ip;
    const bypassIp = process.env.BYPASS_IP_CHECK === 'true' || process.env.VERCEL === '1';
    const isIpCheckEnabled = session.ip_check_enabled !== 0 && session.validation_mode !== 'QR_ONLY' && !bypassIp;

    if (isIpCheckEnabled && !checkSameSubnetOrIp(clientIp, creatorIp)) {
      await run(`
        INSERT INTO attendance_records (
          id, session_id, institution_id, unit_id, person_id, documento, status, reject_reason, message, created_at, client_ip
        ) VALUES (?, ?, ?, ?, ?, ?, 'rejected', 'OUT_OF_SUBNET', ?, ?, ?)
      `, [`rec_${Date.now()}`, session.id, session.institution_id, session.unit_id, person.id, documento, 'Fuera del rango local / Subred del docente.', now.toISOString(), clientIp]);

      return res.status(400).json({
        error: {
          code: 'OUT_OF_SUBNET',
          message: 'Tu dispositivo no está conectado a la misma subred local que el docente. Por favor conéctate al WiFi del aula.'
        }
      });
    }

    // Check for duplicate entry/exit
    const existingRecord = await get(`
      SELECT * FROM attendance_records 
      WHERE session_id = ? AND person_id = ? AND status != 'rejected'
    `, [session.id, person.id]);

    if (session.is_reopened === 1) {
      // Checkout phase
      if (!existingRecord) {
        return res.status(400).json({ error: { code: 'NO_ENTRY_RECORD', message: 'No se puede registrar salida sin haber registrado entrada primero.' } });
      }

      if (existingRecord.hora_salida_real) {
        return res.status(400).json({ error: { code: 'DUPLICATE_EXIT', message: 'Ya has registrado tu salida para esta clase.' } });
      }

      // Update record with checkout time
      const horaSalida = now.toTimeString().split(' ')[0];
      await run(`
        UPDATE attendance_records
        SET hora_salida_real = ?
        WHERE id = ?
      `, [horaSalida, existingRecord.id]);

      const updatedRecord = await get('SELECT * FROM attendance_records WHERE id = ?', [existingRecord.id]);
      return res.json({ data: updatedRecord, message: 'Salida registrada correctamente.' });

    } else {
      // Entry phase
      if (existingRecord) {
        return res.status(400).json({ error: { code: 'DUPLICATE_ENTRY', message: 'Ya registraste tu ingreso a esta clase.' } });
      }

      const { photo_evidence = '', verification_method = 'biometric', biometric_match_score = null } = req.body;

      // Calculate blocks of attendance using pure helper
      const { horasAsistidas, horasFalla, tipoRegistro, status: calculatedStatus } = calculateAttendanceBlocks(
        session.activated_at,
        now.toISOString(),
        6
      );
      const horasProgramadas = 6;

      const recId = `ast_${Date.now().toString().substring(5)}`;
      const horaIngreso = now.toTimeString().split(' ')[0];
      
      // Determine actual record status: if biometrics failed and student forced manual checkin, status is 'pending_biometric'
      const finalStatus = (verification_method === 'manual') ? 'pending_biometric' : calculatedStatus;
      const msg = (verification_method === 'manual') 
        ? 'Validación biométrica no superada. Pendiente de aprobación visual del docente.'
        : (horasFalla > 0 ? `Llegada tarde. Se penaliza con ${horasFalla} hora(s) de inasistencia.` : 'Asistencia puntual registrada (Validado por IA).');

      await run(`
        INSERT INTO attendance_records (
          id, session_id, institution_id, unit_id, person_id, documento, status, message,
          hora_ingreso_real, horas_programadas_sesion, horas_validadas_asistencia, horas_inasistencia_acumulada,
          tipo_registro, created_at, client_ip, photo_evidence, verification_method, biometric_match_score
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        recId, session.id, session.institution_id, session.unit_id, person.id, documento, finalStatus, msg,
        horaIngreso, horasProgramadas, horasAsistidas, horasFalla, tipoRegistro, now.toISOString(), clientIp,
        photo_evidence, verification_method, biometric_match_score
      ]);

      const savedRecord = await get('SELECT * FROM attendance_records WHERE id = ?', [recId]);
      return res.status(200).json({ data: savedRecord });
    }
  } catch (err) {
    console.error('Check-in error:', err);
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Manual override by Teacher (with auto-enrollment support for students without devices)
export const manualOverride = async (req, res) => {
  try {
    const { sessionId, documento, nombre, horas_validadas_asistencia = 6, horas_inasistencia_acumulada = 0, tipo_registro = 'MANUAL_OVERRIDE' } = req.body;
    const cleanDoc = sanitizeDocument(documento);
    
    if (!sessionId || !cleanDoc) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'sessionId y documento válido son requeridos.' } });
    }

    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }
    if (!(await enforceSessionAccess(req, res, session))) return;

    let person = await get('SELECT * FROM people WHERE documento = ? AND active = 1', [cleanDoc]);
    if (!person) {
      if (nombre) {
        const cleanNombre = sanitizeText(nombre, 100);
        const personId = `per_${Date.now()}`;
        const hashedPwd = await bcrypt.hash(cleanDoc, 10);
        await run(`
          INSERT INTO people (id, institution_id, documento, nombre, matricula, active, password, roles, terms_accepted, must_change_password)
          VALUES (?, ?, ?, ?, ?, 1, ?, ?, 1, 1)
        `, [personId, session.institution_id, cleanDoc, cleanNombre, `MAT-${cleanDoc}`, hashedPwd, JSON.stringify(['APRENDIZ'])]);

        await run(`
          INSERT INTO enrollments (id, institution_id, unit_id, person_id, active)
          VALUES (?, ?, ?, ?, 1)
        `, [`enr_${Date.now()}`, session.institution_id, session.unit_id, personId]);

        person = await get('SELECT * FROM people WHERE id = ?', [personId]);
      } else {
        return res.status(404).json({ error: { code: 'PERSON_NOT_FOUND', message: 'Aprendiz no registrado. Ingrese el nombre para enrolarlo manualmente.' } });
      }
    }

    const now = new Date();
    const recId = `ast_man_${Date.now().toString().substring(8)}`;
    
    // Check if record exists to update it, or insert new one
    const existing = await get('SELECT * FROM attendance_records WHERE session_id = ? AND person_id = ?', [sessionId, person.id]);
    
    if (existing) {
      await run(`
        UPDATE attendance_records
        SET status = 'PRESENTE',
            horas_validadas_asistencia = ?,
            horas_inasistencia_acumulada = ?,
            tipo_registro = ?,
            message = 'Corregido manualmente por el instructor.'
        WHERE id = ?
      `, [horas_validadas_asistencia, horas_inasistencia_acumulada, tipo_registro, existing.id]);
      
      const updated = await get('SELECT * FROM attendance_records WHERE id = ?', [existing.id]);
      return res.json({ data: updated, message: 'Registro actualizado por corrección manual del instructor.' });
    } else {
      const horaIngreso = now.toTimeString().split(' ')[0];
      await run(`
        INSERT INTO attendance_records (
          id, session_id, institution_id, unit_id, person_id, documento, status, message,
          hora_ingreso_real, horas_programadas_sesion, horas_validadas_asistencia, horas_inasistencia_acumulada,
          tipo_registro, created_at, client_ip
        ) VALUES (?, ?, ?, ?, ?, ?, 'PRESENTE', 'Ingreso manual por falta de dispositivo / contingencia.', ?, 6, ?, ?, ?, ?, 'instructor_override')
      `, [
        recId, sessionId, session.institution_id, session.unit_id, person.id, cleanDoc,
        horaIngreso, horas_validadas_asistencia, horas_inasistencia_acumulada, tipo_registro, now.toISOString()
      ]);
      
      const saved = await get('SELECT * FROM attendance_records WHERE id = ?', [recId]);
      return res.json({ data: saved, message: 'Ingreso manual y asistencia registrada exitosamente.' });
    }
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Manual Late Check-in (Teacher clicks 'Ingreso Retardado' for student)
export const manualLateCheckin = async (req, res) => {
  try {
    const { sessionId, documento } = req.body;
    if (!sessionId || !documento) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'sessionId y documento son requeridos.' } });
    }

    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }

    const person = await get('SELECT * FROM people WHERE documento = ? AND active = 1', [documento]);
    if (!person) {
      return res.status(404).json({ error: { code: 'PERSON_NOT_FOUND', message: 'Persona no encontrada.' } });
    }

    const now = new Date();
    
    // Check if record already exists
    const existing = await get("SELECT * FROM attendance_records WHERE session_id = ? AND person_id = ? AND status != 'rejected'", [sessionId, person.id]);
    if (existing) {
      return res.status(400).json({ error: { code: 'DUPLICATE_ENTRY', message: 'El aprendiz ya tiene un registro de asistencia válido.' } });
    }

    // Calculate blocks of attendance using pure helper
    const { horasAsistidas, horasFalla, tipoRegistro, status } = calculateAttendanceBlocks(
      session.activated_at,
      now.toISOString(),
      6
    );
    const horasProgramadas = 6;

    const recId = `ast_man_late_${Date.now().toString().substring(8)}`;
    const horaIngreso = now.toTimeString().split(' ')[0];

    await run(`
      INSERT INTO attendance_records (
        id, session_id, institution_id, unit_id, person_id, documento, status, message,
        hora_ingreso_real, horas_programadas_sesion, horas_validadas_asistencia, horas_inasistencia_acumulada,
        tipo_registro, created_at, client_ip
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'override-late')
    `, [
      recId, sessionId, session.institution_id, session.unit_id, person.id, documento, status,
      `Ingreso retardado manual. Horas de falla: ${horasFalla}.`,
      horaIngreso, horasProgramadas, horasAsistidas, horasFalla, tipoRegistro, now.toISOString()
    ]);

    const saved = await get('SELECT * FROM attendance_records WHERE id = ?', [recId]);
    return res.json({ data: saved, message: 'Ingreso retardado manual registrado con éxito.' });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Real-time details
export const getPresent = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const rows = await query(`
      SELECT r.*, p.nombre
      FROM attendance_records r
      JOIN people p ON r.person_id = p.id
      WHERE r.session_id = ? AND r.status IN ('accepted', 'ASISTENCIA_PARCIAL', 'PRESENTE')
    `, [sessionId]);
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getAbsent = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }

    // Absents are people enrolled in the unit that don't have an accepted record
    const rows = await query(`
      SELECT p.id, p.documento, p.nombre, p.matricula
      FROM people p
      JOIN enrollments e ON p.id = e.person_id
      WHERE e.unit_id = ? AND e.active = 1 AND p.active = 1
      AND p.id NOT IN (
        SELECT person_id FROM attendance_records
        WHERE session_id = ? AND status IN ('accepted', 'ASISTENCIA_PARCIAL', 'PRESENTE')
      )
    `, [session.unit_id, sessionId]);
    
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getRejections = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const rows = await query(`
      SELECT * FROM attendance_records
      WHERE session_id = ? AND status = 'rejected'
      ORDER BY created_at DESC
    `, [sessionId]);
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Session report (Rule 3)
export const getSessionReport = async (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }

    // Resource Authorization
    const userRoles = req.user?.roles || [];
    const isCoord = userRoles.includes('COORDINADOR');
    if (!isCoord && req.user?.id) {
      const isCreator = session.created_by === req.user.id;
      const isAssigned = await get(
        'SELECT id FROM instructor_assignments WHERE instructor_id = ? AND unit_id = ?',
        [req.user.id, session.unit_id]
      );
      if (!isCreator && !isAssigned) {
        return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'No tienes autorización para acceder al reporte de esta sesión.' } });
      }
    }

    // Get all enrolled people for this session's unit
    const enrolled = await query(`
      SELECT p.id, p.documento, p.nombre
      FROM people p
      JOIN enrollments e ON p.id = e.person_id
      WHERE e.unit_id = ? AND e.active = 1 AND p.active = 1
      ORDER BY p.nombre ASC
    `, [session.unit_id]);

    // Get all records for this session
    const records = await query(`
      SELECT * FROM attendance_records WHERE session_id = ? AND status != 'rejected'
    `, [sessionId]);

    const recordMap = new Map(records.map(r => [r.person_id, r]));

    // Get all excuses for this session
    const sessionExcuses = await query(`
      SELECT person_id, status FROM excuses WHERE session_id = ?
    `, [sessionId]);
    const excuseMap = new Map(sessionExcuses.map(ex => [ex.person_id, ex]));

    const horasProgramadas = 6;

    const report = enrolled.map(p => {
      const rec = recordMap.get(p.id);
      const excuse = excuseMap.get(p.id);
      
      let horasAsistidas = 0;
      let horasFalla = horasProgramadas;
      let tipoRegistro = 'FALLA_TOTAL';
      let porcentajeAsistencia = 0.0;
      let estadoLlegada = 'Inasistencia';
      let horaIngreso = '-';

      if (excuse && excuse.status === 'approved') {
        horasAsistidas = horasProgramadas;
        horasFalla = 0;
        tipoRegistro = 'EXCUSA_APROBADA';
        porcentajeAsistencia = 100.0;
        estadoLlegada = 'Excusado';
        horaIngreso = rec ? rec.hora_ingreso_real : '-';
      } else if (excuse && excuse.status === 'pending') {
        estadoLlegada = 'Excusa Pendiente';
        if (rec) {
          horasAsistidas = rec.horas_validadas_asistencia;
          horasFalla = rec.horas_inasistencia_acumulada;
          tipoRegistro = rec.tipo_registro;
          porcentajeAsistencia = parseFloat(((horasAsistidas / horasProgramadas) * 100).toFixed(2));
          horaIngreso = rec.hora_ingreso_real;
        }
      } else if (rec) {
        horasAsistidas = rec.horas_validadas_asistencia;
        horasFalla = rec.horas_inasistencia_acumulada;
        tipoRegistro = rec.tipo_registro;
        porcentajeAsistencia = parseFloat(((horasAsistidas / horasProgramadas) * 100).toFixed(2));
        horaIngreso = rec.hora_ingreso_real;

        if (tipoRegistro === 'REGULAR' || (rec.status === 'PRESENTE' && !tipoRegistro.includes('RETARDO'))) {
          estadoLlegada = 'Temprano';
        } else if (tipoRegistro.includes('RETARDO') || tipoRegistro === 'MANUAL_LATE' || rec.status === 'ASISTENCIA_PARCIAL') {
          estadoLlegada = 'Tarde';
        } else {
          estadoLlegada = 'Temprano';
        }
      }

      return {
        documento: p.documento,
        nombre: p.nombre,
        horas_programadas: horasProgramadas,
        horas_asistidas: horasAsistidas,
        horas_falla: horasFalla,
        porcentaje_asistencia: porcentajeAsistencia,
        tipo_registro: tipoRegistro,
        estado_llegada: estadoLlegada,
        hora_ingreso: horaIngreso,
        hora_salida: rec ? (rec.hora_salida_real || '-') : '-'
      };
    });

    res.json(report);
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Student History
export const getStudentHistory = async (req, res) => {
  try {
    const studentId = req.user.id;

    // 1. Get Ficha enrollment
    const enrollment = await get('SELECT unit_id FROM enrollments WHERE person_id = ? AND active = 1', [studentId]);
    if (!enrollment) {
      return res.json({ data: { history: [], excuses: [] } });
    }

    const unitId = enrollment.unit_id;

    // 2. Get all sessions for this Ficha
    const sessions = await query(`
      SELECT s.*, u.code as unit_code, u.name as unit_name
      FROM attendance_sessions s
      JOIN academic_units u ON s.unit_id = u.id
      WHERE s.unit_id = ?
      ORDER BY s.room_created_at DESC
    `, [unitId]);

    // 3. Get student attendance records
    const records = await query(`
      SELECT * FROM attendance_records 
      WHERE person_id = ? AND status != 'rejected'
    `, [studentId]);

    // 4. Get student submitted excuses with session context
    const excuses = await query(`
      SELECT e.*, s.room_created_at as session_date, u.code as unit_code, u.name as unit_name
      FROM excuses e
      LEFT JOIN attendance_sessions s ON e.session_id = s.id
      LEFT JOIN academic_units u ON s.unit_id = u.id
      WHERE e.person_id = ?
      ORDER BY e.created_at DESC
    `, [studentId]);

    // Merge sessions with records and excuses
    const recordMap = new Map(records.map(r => [r.session_id, r]));
    const excuseMap = new Map(excuses.map(e => [e.session_id, e]));

    const history = sessions.map(s => {
      const rec = recordMap.get(s.id);
      const exc = excuseMap.get(s.id);

      return {
        sessionId: s.id,
        unitCode: s.unit_code,
        unitName: s.unit_name,
        date: s.room_created_at.split('T')[0],
        status: rec ? rec.status : 'FALLA_TOTAL',
        horas_programadas: rec ? rec.horas_programadas_sesion : 6,
        horas_asistidas: rec ? rec.horas_validadas_asistencia : 0,
        horas_falla: rec ? rec.horas_inasistencia_acumulada : 6,
        tipo_registro: rec ? rec.tipo_registro : 'FALLA_TOTAL',
        hora_ingreso: rec ? rec.hora_ingreso_real : '-',
        hora_salida: rec ? (rec.hora_salida_real || '-') : '-',
        excuse: exc ? {
          id: exc.id,
          text: exc.text,
          fileName: exc.file_name,
          status: exc.status
        } : null
      };
    });

    res.json({
      data: {
        history,
        excuses
      }
    });

  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Submit Student Excuse
export const submitExcuse = async (req, res) => {
  try {
    const studentId = req.user.id;
    let { sessionId, text, fileName, fileData } = req.body;

    const cleanText = sanitizeText(text, 1000);
    const cleanFileName = sanitizeText(fileName, 150);

    // Fallback: if sessionId is empty or omitted, resolve student's latest session in their enrolled ficha
    if (!sessionId) {
      const enrollment = await get('SELECT unit_id FROM enrollments WHERE person_id = ? AND active = 1', [studentId]);
      if (enrollment) {
        const latestSession = await get('SELECT id FROM attendance_sessions WHERE unit_id = ? ORDER BY COALESCE(room_created_at, activated_at, created_at) DESC LIMIT 1', [enrollment.unit_id]);
        if (latestSession) {
          sessionId = latestSession.id;
        }
      }
    }

    if (!sessionId || !cleanText) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'sessionId y texto de justificación son obligatorios.' } });
    }

    // Verify session exists
    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }

    // Check if excuse already submitted
    const existing = await get('SELECT * FROM excuses WHERE session_id = ? AND person_id = ?', [sessionId, studentId]);
    if (existing) {
      return res.status(400).json({ error: { code: 'DUPLICATE_EXCUSE', message: 'Ya has enviado una excusa para esta clase.' } });
    }

    // Verify business days deadline (BR-07: 3 working days in America/Bogota)
    const sessionTime = session.activated_at || session.room_created_at || session.created_at || new Date().toISOString();
    const now = new Date();
    const isAllowed = await isWithinBusinessDays(sessionTime, now, 3);
    if (!isAllowed) {
      return res.status(422).json({
        error: {
          code: 'EXCUSE_DEADLINE_EXCEEDED',
          message: 'Regla de negocio BR-07: El aprendiz podrá radicar una excusa únicamente hasta las 23:59:59 del tercer día hábil siguiente a la sesión.'
        }
      });
    }

    const excuseId = `exc_${Date.now()}`;

    await run(`
      INSERT INTO excuses (id, session_id, person_id, text, file_name, file_data, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)
    `, [excuseId, sessionId, studentId, cleanText, cleanFileName || null, fileData || null, now.toISOString()]);

    await createAuditLog(studentId, 'SUBMIT_EXCUSE', 'excuse', excuseId, null, { sessionId, fileName: cleanFileName }, { submissionTime: now.toISOString() });

    const created = await get('SELECT * FROM excuses WHERE id = ?', [excuseId]);
    res.status(201).json({ data: created, message: 'Excusa enviada al instructor correctamente.' });

  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Get Instructor Excuses List
export const getInstructorExcuses = async (req, res) => {
  try {
    const userRoles = req.user?.roles || [];
    const isCoord = userRoles.includes('COORDINADOR');
    const { unitId } = req.query;
    const institutionId = req.user?.institutionId;

    let sql = `
      SELECT e.id, e.session_id, e.person_id, e.text, e.file_name, e.file_data, e.status, e.created_at,
             p.nombre as student_name, p.documento as student_doc,
             COALESCE(s.room_created_at, s.activated_at) as room_created_at,
             u.code as unit_code, u.name as unit_name
      FROM excuses e
      JOIN people p ON e.person_id = p.id
      JOIN attendance_sessions s ON e.session_id = s.id
      JOIN academic_units u ON s.unit_id = u.id
      WHERE 1=1
    `;
    const params = [];

    if (institutionId) {
      sql += ' AND s.institution_id = ?';
      params.push(institutionId);
    }

    if (!isCoord && req.user?.id) {
      sql += ` AND (
        s.unit_id IN (SELECT unit_id FROM instructor_assignments WHERE instructor_id = ?)
        OR s.created_by = ?
      )`;
      params.push(req.user.id, req.user.id);
    }

    if (unitId) {
      sql += ' AND s.unit_id = ?';
      params.push(unitId);
    }

    sql += ' ORDER BY e.created_at DESC';

    const rows = await query(sql, params);
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Resolve Excuse (Approve or Reject)
export const resolveExcuse = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body; // 'approved' or 'rejected'

    if (!status || !['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'El estado debe serapproved o rejected.' } });
    }

    const excuse = await get('SELECT * FROM excuses WHERE id = ?', [id]);
    if (!excuse) {
      return res.status(404).json({ error: { code: 'EXCUSE_NOT_FOUND', message: 'Excusa no encontrada.' } });
    }

    const excuseSession = await get('SELECT * FROM attendance_sessions WHERE id = ?', [excuse.session_id]);
    if (!(await enforceSessionAccess(req, res, excuseSession))) return;

    // Update status in excuses
    await run('UPDATE excuses SET status = ? WHERE id = ?', [status, id]);
    await createAuditLog(req.user?.id || 'system', 'EXCUSE_RESOLVED', 'excuses', id, { status: excuse.status }, { status }, { sessionId: excuse.session_id });

    if (status === 'approved') {
      // Find or create attendance record and mark it justified
      const person = await get('SELECT * FROM people WHERE id = ?', [excuse.person_id]);
      const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [excuse.session_id]);

      const now = new Date();
      const existingRecord = await get('SELECT * FROM attendance_records WHERE session_id = ? AND person_id = ?', [excuse.session_id, excuse.person_id]);

      if (existingRecord) {
        await run(`
          UPDATE attendance_records
          SET status = 'PRESENTE',
              horas_validadas_asistencia = 6,
              horas_inasistencia_acumulada = 0,
              tipo_registro = 'EXCUSA_APROBADA',
              message = 'Falla justificada por excusa aprobada.'
          WHERE id = ?
        `, [existingRecord.id]);
      } else {
        const recId = `ast_exc_${Date.now().toString().substring(8)}`;
        const horaIngreso = '-';
        await run(`
          INSERT INTO attendance_records (
            id, session_id, institution_id, unit_id, person_id, documento, status, message,
            hora_ingreso_real, horas_programadas_sesion, horas_validadas_asistencia, horas_inasistencia_acumulada,
            tipo_registro, created_at, client_ip
          ) VALUES (?, ?, ?, ?, ?, ?, 'PRESENTE', 'Falla justificada por excusa aprobada.', ?, 6, 6, 0, 'EXCUSA_APROBADA', ?, 'override-excuse')
        `, [
          recId, excuse.session_id, session.institution_id, session.unit_id, person.id, person.documento,
          horaIngreso, now.toISOString()
        ]);
      }
    }

    res.json({ message: `Excusa procesada como ${status} con éxito.` });

  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// ── SELF-REGISTER + CHECK-IN via QR ──────────────────────────────────────────
// Student not in DB can register themselves while an active session is open.
export const selfRegisterCheckin = async (req, res) => {
  try {
    const { token } = req.params;
    const { documento, nombre, password, photo_reference } = req.body;

    const cleanDoc = sanitizeDocument(documento);
    const cleanNombre = sanitizeText(nombre, 100);

    if (!cleanDoc || !cleanNombre) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Documento válido y nombre son requeridos.' } });
    }

    // Find session by token (BR-03: 15s window + 1 leeway slot)
    let session = null;
    const activeSessions = await query("SELECT * FROM attendance_sessions WHERE LOWER(status) IN ('active', 'open')");
    const allowedOffsets = getAllowedQrOffsetsMs();
    for (const s of activeSessions) {
      for (const offset of allowedOffsets) {
        const tok = generateQrToken(s.id, offset);
        if (matchToken(token, tok) || (s.qr_token && matchToken(token, s.qr_token))) { session = s; break; }
      }
      if (session) break;
    }

    if (!session) {
      return res.status(400).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada o token QR inválido/vencido.' } });
    }

    // Check room not expired
    const now = new Date();
    if (now > new Date(session.room_expires_at)) {
      return res.status(400).json({ error: { code: 'ROOM_EXPIRED', message: 'La ventana de 15 minutos ha cerrado.' } });
    }

    // Create or find person
    let person = await get('SELECT * FROM people WHERE documento = ? AND active = 1', [cleanDoc]);
    let isNewStudent = false;

    if (!person) {
      isNewStudent = true;
      const personId = `per_${Date.now()}`;
      const hashedPwd = await bcrypt.hash(password || cleanDoc, 10);
      await run(`
        INSERT INTO people (id, institution_id, documento, nombre, matricula, active, password, roles, photo_reference, terms_accepted)
        VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, 1)
      `, [personId, session.institution_id, cleanDoc, cleanNombre, `MAT-${cleanDoc}`, hashedPwd, JSON.stringify(['APRENDIZ']), photo_reference]);

      await run(`
        INSERT INTO enrollments (id, institution_id, unit_id, person_id, active)
        VALUES (?, ?, ?, ?, 1)
      `, [`enr_${personId}_${session.unit_id}`, session.institution_id, session.unit_id, personId]);

      person = await get('SELECT * FROM people WHERE id = ?', [personId]);
    } else {
      // Enroll in unit if not already
      const enrollment = await get('SELECT * FROM enrollments WHERE unit_id = ? AND person_id = ? AND active = 1', [session.unit_id, person.id]);
      if (!enrollment) {
        await run(`
          INSERT INTO enrollments (id, institution_id, unit_id, person_id, active)
          VALUES (?, ?, ?, ?, 1)
        `, [`enr_${person.id}_${session.unit_id}`, session.institution_id, session.unit_id, person.id]);
      }
    }

    // Check duplicate
    const existingRecord = await get(`SELECT * FROM attendance_records WHERE session_id = ? AND person_id = ? AND status != 'rejected'`, [session.id, person.id]);
    if (existingRecord) {
      const tokenPayload = {
        id: person.id,
        institutionId: person.institution_id,
        documento: person.documento,
        nombre: person.nombre,
        roles: ['APRENDIZ']
      };
      const sessionToken = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: '24h' });

      return res.status(200).json({
        data: {
          token: sessionToken,
          person: {
            id: person.id,
            nombre: person.nombre,
            documento: person.documento,
            photo_reference: person.photo_reference || '',
            terms_accepted: person.terms_accepted || 0,
            alreadyRegistered: true
          }
        }
      });
    }

    // IP Subnet Validation
    const clientIp = getClientIp(req);
    const creatorIp = session.creator_ip;
    const bypassIp = process.env.BYPASS_IP_CHECK === 'true' || process.env.VERCEL === '1';
    const isIpCheckEnabled = session.ip_check_enabled !== 0 && session.validation_mode !== 'QR_ONLY' && !bypassIp;

    if (isIpCheckEnabled && !checkSameSubnetOrIp(clientIp, creatorIp)) {
      await run(`
        INSERT INTO attendance_records (
          id, session_id, institution_id, unit_id, person_id, documento, status, reject_reason, message, created_at, client_ip
        ) VALUES (?, ?, ?, ?, ?, ?, 'rejected', 'OUT_OF_SUBNET', ?, ?, ?)
      `, [`rec_${Date.now()}`, session.id, session.institution_id, session.unit_id, person.id, documento, 'Fuera del rango local / Subred del docente (auto-registro).', now.toISOString(), clientIp]);

      return res.status(400).json({
        error: {
          code: 'OUT_OF_SUBNET',
          message: 'Tu dispositivo no está conectado a la misma subred local que el docente. Por favor conéctate al WiFi del aula.'
        }
      });
    }

    // Calculate attendance blocks using pure helper
    const { horasAsistidas, horasFalla, tipoRegistro, status } = calculateAttendanceBlocks(
      session.activated_at,
      now.toISOString(),
      6
    );
    const horasProgramadas = 6;

    const recId = `ast_sr_${Date.now()}`;
    const horaIngreso = now.toTimeString().split(' ')[0];

    await run(`
      INSERT INTO attendance_records (
        id, session_id, institution_id, unit_id, person_id, documento, status, message,
        hora_ingreso_real, horas_programadas_sesion, horas_validadas_asistencia,
        horas_inasistencia_acumulada, tipo_registro, created_at, client_ip
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      recId, session.id, session.institution_id, session.unit_id, person.id, documento,
      status,
      isNewStudent ? 'Registro nuevo. Asistencia marcada automáticamente.' : (horasFalla > 0 ? `Llegada tarde. ${horasFalla}h de inasistencia.` : 'Asistencia puntual registrada.'),
      horaIngreso, horasProgramadas, horasAsistidas, horasFalla, tipoRegistro, now.toISOString(), getClientIp(req)
    ]);

    const tokenPayload = {
      id: person.id,
      institutionId: person.institution_id,
      documento: person.documento,
      nombre: person.nombre,
      roles: ['APRENDIZ']
    };
    const sessionToken = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: '24h' });

    return res.status(201).json({
      data: {
        token: sessionToken,
        person: {
          id: person.id,
          nombre: person.nombre,
          documento: person.documento,
          photo_reference: person.photo_reference || '',
          terms_accepted: 1
        }
      }
    });
  } catch (err) {
    console.error('Self-register error:', err);
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// ── SUBMIT LATE REQUEST ───────────────────────────────────────────────────────
// Student arrives late or session expired; sends a request to the instructor.
export const submitLateRequest = async (req, res) => {
  try {
    const { token } = req.params;
    const { documento, nombre, justification } = req.body;

    const cleanDoc = sanitizeDocument(documento);
    const cleanNombre = sanitizeText(nombre, 100);
    const cleanJustif = sanitizeText(justification, 500);

    if (!cleanDoc || !cleanNombre) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Documento válido y nombre son requeridos.' } });
    }

    // Find session by token (wider window: up to 2 hours back for expired sessions)
    let session = null;
    const sessions = await query("SELECT * FROM attendance_sessions WHERE status != 'draft' ORDER BY created_at DESC");
    for (const s of sessions) {
      for (let i = -1; i <= 120; i++) { // 120 x 60s = 2 hours
        const tok = generateQrToken(s.id, -i * 60000);
        if (matchToken(token, tok)) { session = s; break; }
      }
      if (session) break;
    }

    if (!session) {
      return res.status(400).json({ error: { code: 'SESSION_NOT_FOUND', message: 'No se pudo identificar la sesión de clase con este QR.' } });
    }

    const requestId = `lr_${Date.now()}`;
    const now = new Date();

    await run(`
      INSERT INTO late_requests (id, session_id, institution_id, unit_id, documento, nombre, justification, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)
    `, [requestId, session.id, session.institution_id, session.unit_id, cleanDoc, cleanNombre, cleanJustif, now.toISOString()]);

    return res.status(201).json({
      data: { id: requestId, message: 'Solicitud enviada al instructor. Te notificarán cuando sea aprobada.' }
    });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// ── GET INSTRUCTOR LATE REQUESTS ──────────────────────────────────────────────
export const getInstructorLateRequests = async (req, res) => {
  try {
    const person = req.user;

    // Get all units in this instructor's institution
    const units = await query(`
      SELECT id FROM academic_units WHERE institution_id = ?
    `, [person.institutionId]);

    const unitIds = units.map(u => u.id);

    if (unitIds.length === 0) {
      return res.json({ data: [] });
    }

    const placeholders = unitIds.map(() => '?').join(',');
    const rows = await query(`
      SELECT lr.*, au.name as ficha_name, au.code as ficha_code
      FROM late_requests lr
      JOIN academic_units au ON lr.unit_id = au.id
      WHERE lr.unit_id IN (${placeholders})
      ORDER BY lr.created_at DESC
    `, unitIds);

    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// ── RESOLVE LATE REQUEST ──────────────────────────────────────────────────────
export const resolveLateRequest = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, horasDescontar = 1 } = req.body; // 'approved' or 'rejected'

    const request = await get('SELECT * FROM late_requests WHERE id = ?', [id]);
    if (!request) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Solicitud no encontrada.' } });

    if (status === 'approved') {
      const now = new Date();

      // Find or create person
      let person = await get('SELECT * FROM people WHERE documento = ? AND active = 1', [request.documento]);
      if (!person) {
        const personId = `per_lr_${Date.now()}`;
        await run(`
          INSERT INTO people (id, institution_id, documento, nombre, matricula, active, password, roles)
          VALUES (?, ?, ?, ?, ?, 1, ?, ?)
        `, [personId, request.institution_id, request.documento, request.nombre, `MAT-${request.documento}`, request.documento, JSON.stringify(['APRENDIZ'])]);

        await run(`
          INSERT INTO enrollments (id, institution_id, unit_id, person_id, active)
          VALUES (?, ?, ?, ?, 1)
        `, [`enr_${personId}_${request.unit_id}`, request.institution_id, request.unit_id, personId]);

        person = await get('SELECT * FROM people WHERE id = ?', [personId]);
      }

      const horasAsistidas = Math.max(0, 6 - horasDescontar);
      const horasFalla = Number(horasDescontar);

      const existing = await get(`SELECT * FROM attendance_records WHERE session_id = ? AND person_id = ? AND status != 'rejected'`, [request.session_id, person.id]);

      if (existing) {
        await run(`
          UPDATE attendance_records
          SET horas_validadas_asistencia = ?, horas_inasistencia_acumulada = ?, tipo_registro = 'LATE_VALIDATED', status = 'ASISTENCIA_PARCIAL',
              message = 'Ingreso tardío validado por el instructor.'
          WHERE id = ?
        `, [horasAsistidas, horasFalla, existing.id]);
      } else {
        const recId = `ast_lv_${Date.now()}`;
        const horaIngreso = now.toTimeString().split(' ')[0];
        await run(`
          INSERT INTO attendance_records (
            id, session_id, institution_id, unit_id, person_id, documento, status, message,
            hora_ingreso_real, horas_programadas_sesion, horas_validadas_asistencia,
            horas_inasistencia_acumulada, tipo_registro, created_at, client_ip
          ) VALUES (?, ?, ?, ?, ?, ?, 'ASISTENCIA_PARCIAL', 'Ingreso tardío validado por el instructor.', ?, 6, ?, ?, 'LATE_VALIDATED', ?, 'late-validated')
        `, [recId, request.session_id, request.institution_id, request.unit_id, person.id, request.documento,
            horaIngreso, horasAsistidas, horasFalla, now.toISOString()]);
      }
    }

    await run('UPDATE late_requests SET status = ?, horas_descontar = ? WHERE id = ?', [status, horasDescontar, id]);

    res.json({ data: { id, status, message: status === 'approved' ? 'Ingreso tardío aprobado.' : 'Solicitud rechazada.' } });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// ── COORDINATOR CONTROLLERS ───────────────────────────────────────────────────

export const getCoordInstructors = async (req, res) => {
  try {
    const institutionId = req.user.institutionId;
    const instructors = await query(
      `SELECT id, documento, nombre, active, roles FROM people 
       WHERE institution_id = ? AND roles LIKE '%INSTRUCTOR%'
       ORDER BY nombre ASC`,
      [institutionId]
    );

    // Fetch all assignments for these instructors in this institution
    const assignments = await query(
      `SELECT ia.instructor_id, u.id as unit_id, u.code as unit_code, u.name as unit_name
       FROM instructor_assignments ia
       JOIN academic_units u ON ia.unit_id = u.id
       WHERE ia.institution_id = ? AND u.active = 1
       ORDER BY u.code ASC`,
      [institutionId]
    );

    const assignMap = new Map();
    for (const a of assignments) {
      if (!assignMap.has(a.instructor_id)) {
        assignMap.set(a.instructor_id, []);
      }
      assignMap.get(a.instructor_id).push({
        id: a.unit_id,
        code: a.unit_code,
        name: a.unit_name
      });
    }

    const data = instructors.map(inst => ({
      ...inst,
      assigned_units: assignMap.get(inst.id) || []
    }));

    res.json({ data });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getInstructorUnits = async (req, res) => {
  try {
    const instructorId = req.user.id;
    const institutionId = req.user.institutionId;

    const units = await query(`
      SELECT u.id, u.code, u.name, u.jornada, u.modalidad
      FROM academic_units u
      JOIN instructor_assignments ia ON u.id = ia.unit_id
      WHERE ia.instructor_id = ? AND ia.institution_id = ? AND u.active = 1
      ORDER BY u.code ASC
    `, [instructorId, institutionId]);

    res.json({ data: units });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const assignInstructorUnits = async (req, res) => {
  try {
    const { id } = req.params; // instructor id
    const { unitIds } = req.body; // array of unit ids
    const institutionId = req.user.institutionId;

    if (!Array.isArray(unitIds)) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'unitIds debe ser un arreglo de identificadores de ficha.' } });
    }

    // 1. Verify instructor exists in this institution and has role INSTRUCTOR
    const instructor = await get(
      'SELECT id, nombre, documento, roles, institution_id FROM people WHERE id = ? AND institution_id = ?',
      [id, institutionId]
    );
    if (!instructor) {
      return res.status(404).json({ error: { code: 'INSTRUCTOR_NOT_FOUND', message: 'Instructor no encontrado en esta institución.' } });
    }
    const roles = typeof instructor.roles === 'string' ? JSON.parse(instructor.roles || '[]') : (instructor.roles || []);
    if (!roles.includes('INSTRUCTOR')) {
      return res.status(400).json({ error: { code: 'INVALID_ROLE', message: 'La persona seleccionada no tiene el rol de INSTRUCTOR.' } });
    }

    // 2. Verify all unitIds exist in this institution and are active
    if (unitIds.length > 0) {
      const validUnits = await query(
        `SELECT id FROM academic_units WHERE institution_id = ? AND active = 1`,
        [institutionId]
      );
      const validUnitSet = new Set(validUnits.map(u => u.id));
      for (const uId of unitIds) {
        if (!validUnitSet.has(uId)) {
          return res.status(400).json({
            error: { code: 'INVALID_UNIT', message: `La ficha con ID ${uId} no existe, no está activa o pertenece a otra institución.` }
          });
        }
      }
    }

    // Get previous assignments for audit log
    const prevAssignments = await query(
      'SELECT unit_id FROM instructor_assignments WHERE instructor_id = ? AND institution_id = ?',
      [id, institutionId]
    );
    const prevUnitIds = prevAssignments.map(a => a.unit_id);

    // 3. Atomically replace assignments
    await run('DELETE FROM instructor_assignments WHERE instructor_id = ? AND institution_id = ?', [id, institutionId]);

    const now = new Date().toISOString();
    for (const uId of unitIds) {
      const asgId = `asg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
      await run(`
        INSERT INTO instructor_assignments (id, institution_id, unit_id, instructor_id, created_at)
        VALUES (?, ?, ?, ?, ?)
      `, [asgId, institutionId, uId, id, now]);
    }

    // 4. Audit log
    await createAuditLog(
      req.user.id,
      'ASSIGN_INSTRUCTOR_UNITS',
      'person',
      id,
      { assigned_units: prevUnitIds },
      { assigned_units: unitIds },
      { instructor_nombre: instructor.nombre, instructor_doc: instructor.documento }
    );

    // Retrieve updated assigned units
    const updatedAssignments = await query(`
      SELECT u.id, u.code, u.name
      FROM instructor_assignments ia
      JOIN academic_units u ON ia.unit_id = u.id
      WHERE ia.instructor_id = ? AND ia.institution_id = ?
      ORDER BY u.code ASC
    `, [id, institutionId]);

    res.json({
      ok: true,
      data: {
        instructorId: id,
        assigned_units: updatedAssignments
      },
      message: 'Fichas asignadas exitosamente al instructor.'
    });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const createInstructor = async (req, res) => {
  try {
    const { documento, nombre, password, unitIds } = req.body;
    const institutionId = req.user.institutionId;

    if (!documento || !nombre || !password) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Documento, nombre y contraseña son requeridos.' } });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: { code: 'INVALID_PASSWORD_LENGTH', message: 'La contraseña debe tener mínimo 6 caracteres.' } });
    }

    const existing = await get(
      'SELECT id FROM people WHERE documento = ? AND institution_id = ?',
      [documento, institutionId]
    );
    if (existing) {
      return res.status(409).json({ error: { code: 'DUPLICATE_ERROR', message: 'Ya existe un usuario con ese documento.' } });
    }

    const hashedPwd = await bcrypt.hash(password, 10);
    const id = `per_inst_${Date.now()}`;
    await run(
      `INSERT INTO people (id, institution_id, documento, nombre, matricula, active, password, roles)
       VALUES (?, ?, ?, ?, ?, 1, ?, ?)`,
      [id, institutionId, documento, nombre, `MAT-${documento}`, hashedPwd, JSON.stringify(['INSTRUCTOR'])]
    );

    // If unitIds provided, assign them
    if (Array.isArray(unitIds) && unitIds.length > 0) {
      const now = new Date().toISOString();
      for (const uId of unitIds) {
        const asgId = `asg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
        await run(`
          INSERT INTO instructor_assignments (id, institution_id, unit_id, instructor_id, created_at)
          VALUES (?, ?, ?, ?, ?)
        `, [asgId, institutionId, uId, id, now]);
      }
    }

    await createAuditLog(req.user.id, 'CREATE_INSTRUCTOR', 'person', id, null, { documento, nombre, unitIds });

    res.status(201).json({ data: { id, documento, nombre, active: 1, roles: ['INSTRUCTOR'] } });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const updateInstructor = async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, password, active, unitIds } = req.body;
    const institutionId = req.user.institutionId;

    const instructor = await get('SELECT * FROM people WHERE id = ? AND institution_id = ?', [id, institutionId]);
    if (!instructor) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Instructor no encontrado.' } });
    }

    let queryStr = 'UPDATE people SET nombre = ?, active = ?';
    let params = [nombre !== undefined ? nombre : instructor.nombre, active !== undefined ? Number(active) : instructor.active];

    if (password && typeof password === 'string' && password.trim().length > 0) {
      if (password.trim().length < 6) {
        return res.status(400).json({ error: { code: 'INVALID_PASSWORD_LENGTH', message: 'La contraseña debe tener mínimo 6 caracteres.' } });
      }
      const hashedPwd = await bcrypt.hash(password.trim(), 10);
      queryStr += ', password = ?';
      params.push(hashedPwd);
    }

    queryStr += ' WHERE id = ?';
    params.push(id);

    await run(queryStr, params);

    // If unitIds provided, update assignments
    if (Array.isArray(unitIds)) {
      await run('DELETE FROM instructor_assignments WHERE instructor_id = ? AND institution_id = ?', [id, institutionId]);
      const now = new Date().toISOString();
      for (const uId of unitIds) {
        const asgId = `asg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
        await run(`
          INSERT INTO instructor_assignments (id, institution_id, unit_id, instructor_id, created_at)
          VALUES (?, ?, ?, ?, ?)
        `, [asgId, institutionId, uId, id, now]);
      }
    }

    await createAuditLog(req.user.id, 'UPDATE_INSTRUCTOR', 'person', id, { nombre: instructor.nombre, active: instructor.active }, { nombre, active, unitIds });

    res.json({ data: { id, message: 'Instructor actualizado con éxito.' } });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getCoordFichas = async (req, res) => {
  try {
    const institutionId = req.user.institutionId;
    const rows = await query(
      `SELECT au.id, au.code, au.name, au.jornada, au.modalidad, au.status, au.active, COUNT(e.id) as learners_count
       FROM academic_units au
       LEFT JOIN enrollments e ON au.id = e.unit_id AND e.active = 1
       WHERE au.institution_id = ? AND au.type = 'ficha'
       GROUP BY au.id
       ORDER BY au.code ASC`,
      [institutionId]
    );
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const createFicha = async (req, res) => {
  try {
    const { code, name, jornada = 'DIURNA', modalidad = 'PRESENCIAL' } = req.body;
    const institutionId = req.user.institutionId;

    if (!code || !name) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Código y nombre son requeridos.' } });
    }

    const cleanJornada = (jornada || 'DIURNA').toString().trim().toUpperCase();
    const cleanModalidad = (modalidad || 'PRESENCIAL').toString().trim().toUpperCase();

    const existing = await get(
      'SELECT id FROM academic_units WHERE code = ? AND institution_id = ?',
      [code, institutionId]
    );
    if (existing) {
      return res.status(409).json({ error: { code: 'DUPLICATE_ERROR', message: 'Ya existe una ficha con ese código.' } });
    }

    const id = `unit_ficha_${code}`;
    await run(
      `INSERT INTO academic_units (id, institution_id, code, name, type, jornada, modalidad, status, active)
       VALUES (?, ?, ?, ?, 'ficha', ?, ?, 'ACTIVE', 1)`,
      [id, institutionId, code, name, cleanJornada, cleanModalidad]
    );

    await createAuditLog(req.user.id, 'CREATE_FICHA', 'ficha', id, null, { code, name, jornada: cleanJornada, modalidad: cleanModalidad });

    res.status(201).json({ data: { id, code, name, jornada: cleanJornada, modalidad: cleanModalidad, status: 'ACTIVE', active: 1, learners_count: 0 } });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const updateFicha = async (req, res) => {
  try {
    const { id } = req.params;
    const { code, name, active, jornada, modalidad } = req.body;
    const institutionId = req.user.institutionId;

    const unit = await get('SELECT * FROM academic_units WHERE id = ? AND institution_id = ?', [id, institutionId]);
    if (!unit) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Ficha no encontrada.' } });
    }

    const cleanJornada = jornada !== undefined ? jornada.toString().trim().toUpperCase() : (unit.jornada || 'DIURNA');
    const cleanModalidad = modalidad !== undefined ? modalidad.toString().trim().toUpperCase() : (unit.modalidad || 'PRESENCIAL');

    const queryStr = 'UPDATE academic_units SET code = ?, name = ?, active = ?, jornada = ?, modalidad = ? WHERE id = ?';
    const params = [
      code !== undefined ? code : unit.code,
      name !== undefined ? name : unit.name,
      active !== undefined ? Number(active) : unit.active,
      cleanJornada,
      cleanModalidad,
      id
    ];

    await run(queryStr, params);
    await createAuditLog(req.user.id, 'UPDATE_FICHA', 'ficha', id, { code: unit.code, name: unit.name }, { code, name, jornada: cleanJornada, modalidad: cleanModalidad, active });

    res.json({ data: { id, message: 'Ficha actualizada con éxito.' } });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// ── TWO-PERSON RULE (REGLA DE 4 OJOS / BR-08) ─────────────────────────────────

export const requestFichaDeletion = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason = 'Eliminación solicitada por coordinación' } = req.body;
    const requesterId = req.user.id;
    const institutionId = req.user.institutionId;

    const unit = await get('SELECT * FROM academic_units WHERE id = ? AND institution_id = ?', [id, institutionId]);
    if (!unit) {
      return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Ficha no encontrada.' } });
    }

    const existingReq = await get(`SELECT * FROM deletion_requests WHERE entity_type = 'ficha' AND entity_id = ? AND status = 'PENDING_APPROVAL'`, [id]);
    if (existingReq) {
      return res.status(409).json({ error: { code: 'DUPLICATE_DELETION_REQUEST', message: 'Ya existe una solicitud de eliminación pendiente para esta ficha.' } });
    }

    const reqId = `del_req_${Date.now()}`;
    const now = new Date().toISOString();

    await run(`
      INSERT INTO deletion_requests (id, entity_type, entity_id, requested_by, status, reason, created_at)
      VALUES (?, 'ficha', ?, ?, 'PENDING_APPROVAL', ?, ?)
    `, [reqId, id, requesterId, reason, now]);

    await run(`UPDATE academic_units SET status = 'PENDING_DELETION' WHERE id = ?`, [id]);

    await createAuditLog(requesterId, 'REQUEST_FICHA_DELETION', 'ficha', id, { status: unit.status }, { status: 'PENDING_DELETION', requestId: reqId }, { reason });

    res.status(202).json({
      data: {
        requestId: reqId,
        status: 'PENDING_APPROVAL',
        message: 'Solicitud de eliminación radicada. Requiere la aprobación de un segundo coordinador (Regla de 4 ojos / BR-08).'
      }
    });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const approveFichaDeletion = async (req, res) => {
  try {
    const { requestId } = req.params;
    const approverId = req.user.id;

    const delReq = await get('SELECT * FROM deletion_requests WHERE id = ?', [requestId]);
    if (!delReq) {
      return res.status(404).json({ error: { code: 'REQUEST_NOT_FOUND', message: 'Solicitud de eliminación no encontrada.' } });
    }

    if (delReq.requested_by === approverId) {
      return res.status(403).json({
        error: {
          code: 'SELF_APPROVAL_FORBIDDEN',
          message: 'Regla de negocio BR-08: Un coordinador no puede autoaprobar su propia solicitud de eliminación. Se requiere un segundo coordinador.'
        }
      });
    }

    if (delReq.status !== 'PENDING_APPROVAL') {
      return res.status(409).json({ error: { code: 'INVALID_STATUS', message: `La solicitud ya fue procesada (Estado: ${delReq.status}).` } });
    }

    const now = new Date().toISOString();

    await run(`
      UPDATE deletion_requests
      SET status = 'APPROVED', approved_by = ?, resolved_at = ?
      WHERE id = ? AND status = 'PENDING_APPROVAL' AND requested_by <> ?
    `, [approverId, now, requestId, approverId]);

    await run(`UPDATE academic_units SET active = 0, status = 'DELETED' WHERE id = ?`, [delReq.entity_id]);

    await createAuditLog(approverId, 'APPROVE_FICHA_DELETION', 'ficha', delReq.entity_id, { status: 'PENDING_DELETION' }, { status: 'DELETED', active: 0 }, { requestId, requestedBy: delReq.requested_by });

    res.json({
      data: {
        requestId,
        status: 'APPROVED',
        message: 'Ficha eliminada exitosamente tras aprobación dual de 4 ojos.'
      }
    });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const rejectFichaDeletion = async (req, res) => {
  try {
    const { requestId } = req.params;
    const approverId = req.user.id;
    const { rejectionReason = 'Rechazada por coordinación' } = req.body;

    const delReq = await get('SELECT * FROM deletion_requests WHERE id = ?', [requestId]);
    if (!delReq) {
      return res.status(404).json({ error: { code: 'REQUEST_NOT_FOUND', message: 'Solicitud no encontrada.' } });
    }

    if (delReq.requested_by === approverId) {
      return res.status(403).json({
        error: {
          code: 'SELF_APPROVAL_FORBIDDEN',
          message: 'Regla de negocio BR-08: No puedes resolver tu propia solicitud de eliminación.'
        }
      });
    }

    if (delReq.status !== 'PENDING_APPROVAL') {
      return res.status(409).json({ error: { code: 'INVALID_STATUS', message: 'La solicitud ya fue procesada.' } });
    }

    const now = new Date().toISOString();
    await run(`
      UPDATE deletion_requests
      SET status = 'REJECTED', approved_by = ?, resolved_at = ?
      WHERE id = ? AND status = 'PENDING_APPROVAL'
    `, [approverId, now, requestId]);

    await run(`UPDATE academic_units SET status = 'ACTIVE' WHERE id = ?`, [delReq.entity_id]);

    await createAuditLog(approverId, 'REJECT_FICHA_DELETION', 'ficha', delReq.entity_id, { status: 'PENDING_DELETION' }, { status: 'ACTIVE' }, { requestId, rejectionReason });

    res.json({
      data: {
        requestId,
        status: 'REJECTED',
        message: 'Solicitud rechazada. La ficha permanece activa.'
      }
    });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

export const getPendingDeletionRequests = async (req, res) => {
  try {
    const rows = await query(`
      SELECT dr.id, dr.entity_type, dr.entity_id, dr.requested_by, dr.status, dr.reason, dr.created_at,
             p.nombre as requester_name, p.documento as requester_doc,
             u.code as unit_code, u.name as unit_name
      FROM deletion_requests dr
      JOIN people p ON dr.requested_by = p.id
      LEFT JOIN academic_units u ON dr.entity_id = u.id
      WHERE dr.status = 'PENDING_APPROVAL'
      ORDER BY dr.created_at DESC
    `);
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Student self late check-in
export const studentLateCheckin = async (req, res) => {
  try {
    const { token, documento, password, justification } = req.body;
    
    if (!token || !documento || !password) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Token, documento y contraseña son requeridos.' } });
    }

    // Find person
    const person = await get('SELECT * FROM people WHERE documento = ? AND active = 1', [documento]);
    if (!person) {
      return res.status(404).json({ error: { code: 'PERSON_NOT_FOUND', message: 'Persona no encontrada.' } });
    }

    // Check password
    let isMatch = false;
    if (person.password.startsWith('$2b$') || person.password.startsWith('$2a$')) {
      isMatch = await bcrypt.compare(password, person.password);
    } else {
      isMatch = (password === person.password);
    }

    if (!isMatch) {
      return res.status(401).json({ error: { code: 'INVALID_PASSWORD', message: 'Contraseña incorrecta.' } });
    }

    // Identify session from token
    let session = null;
    const sessions = await query("SELECT * FROM attendance_sessions WHERE status != 'draft' ORDER BY created_at DESC");
    for (const s of sessions) {
      for (let i = -1; i <= 120; i++) { // 120 x 60s = 2 hours window
        const tok = generateQrToken(s.id, -i * 60000);
        if (matchToken(token, tok)) { session = s; break; }
      }
      if (session) break;
    }

    if (!session) {
      return res.status(400).json({ error: { code: 'SESSION_NOT_FOUND', message: 'No se pudo identificar una sesión de clase activa.' } });
    }

    // Check duplicate
    const existing = await get("SELECT * FROM attendance_records WHERE session_id = ? AND person_id = ? AND status != 'rejected'", [session.id, person.id]);
    if (existing) {
      return res.status(400).json({ error: { code: 'DUPLICATE_ENTRY', message: 'Ya has registrado tu asistencia para esta clase.' } });
    }

    const now = new Date();
    // Calculate blocks of attendance using pure helper
    const { horasAsistidas, horasFalla, tipoRegistro, status } = calculateAttendanceBlocks(
      session.activated_at,
      now.toISOString(),
      6
    );

    const recId = `ast_student_late_${Date.now().toString().substring(8)}`;
    const horaIngreso = now.toTimeString().split(' ')[0];

    await run(`
      INSERT INTO attendance_records (
        id, session_id, institution_id, unit_id, person_id, documento, status, message,
        hora_ingreso_real, horas_programadas_sesion, horas_validadas_asistencia, horas_inasistencia_acumulada,
        tipo_registro, created_at, client_ip
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      recId, session.id, session.institution_id, session.unit_id, person.id, documento, status,
      justification || 'Registro tardío manual del estudiante.',
      horaIngreso, 6, horasAsistidas, horasFalla, tipoRegistro, now.toISOString(), getClientIp(req)
    ]);

    res.status(201).json({
      data: {
        id: recId,
        horas_validadas: horasAsistidas,
        horas_inasistencia: horasFalla,
        message: 'Asistencia tardía registrada con éxito.'
      }
    });

  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Submit session evidence (Instructor)
export const submitSessionEvidence = async (req, res) => {
  try {
    const sessionId = req.params.sessionId || req.params.id;
    const file_name = req.body.file_name || req.body.fileName;
    const file_data = req.body.file_data || req.body.fileData;
    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }

    // Verify institution
    if (req.user?.institutionId && session.institution_id !== req.user.institutionId) {
      return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'No tienes acceso a esta sesión.' } });
    }

    // Authorization: coordinator, or creator of session, or instructor assigned to unit
    const userRoles = req.user?.roles || [];
    const isCoord = userRoles.includes('COORDINADOR');
    if (!isCoord && req.user?.id) {
      const isCreator = session.created_by === req.user.id;
      const isAssigned = await get(
        'SELECT id FROM instructor_assignments WHERE instructor_id = ? AND unit_id = ?',
        [req.user.id, session.unit_id]
      );
      if (!isCreator && !isAssigned) {
        return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'No estás autorizado para entregar evidencias en esta sesión.' } });
      }
    }

    const now = new Date();

    // If file_name and file_data are provided, validate strictly (canonical Base64, MIME, size, magic bytes)
    if (file_data) {
      const cleanFileName = sanitizeText(file_name || 'reporte_evidencia.xlsx', 120);
      let validated;
      let bytes;
      try {
        const parsed = parseDataUrlOrBase64(file_data);
        bytes = decodeBase64ToBytes(parsed.base64);
        validated = validateEvidencePayload({
          fileName: cleanFileName,
          rawFileData: file_data,
          decodedBytes: bytes,
          declaredMimeOverride: req.body.mimeType || req.body.mime_type
        });
      } catch (err) {
        if (err instanceof DomainValidationError) {
          return res.status(err.status).json({ error: { code: err.code, message: err.message } });
        }
        throw err;
      }

      const hash = computeSha256Hex(bytes);

      await run(`
        UPDATE attendance_sessions
        SET evidence_submitted = 1,
            evidence_submitted_at = ?,
            evidence_file_name = ?,
            evidence_file_data = ?,
            evidence_mime_type = ?,
            evidence_file_size = ?,
            evidence_hash = ?
        WHERE id = ?
      `, [now.toISOString(), cleanFileName, file_data, validated.mimeType, validated.sizeBytes, hash, sessionId]);

      await createAuditLog(
        req.user?.id || 'INSTRUCTOR',
        'SUBMIT_EVIDENCE',
        'session',
        sessionId,
        { evidence_submitted: session.evidence_submitted },
        { evidence_submitted: 1, evidence_file_name: cleanFileName, evidence_file_size: validated.sizeBytes, hash }
      );
    } else {
      await run(`
        UPDATE attendance_sessions
        SET evidence_submitted = 1, evidence_submitted_at = ?
        WHERE id = ?
      `, [now.toISOString(), sessionId]);

      await createAuditLog(
        req.user?.id || 'INSTRUCTOR',
        'SUBMIT_EVIDENCE',
        'session',
        sessionId,
        { evidence_submitted: session.evidence_submitted },
        { evidence_submitted: 1 }
      );
    }

    res.json({ ok: true, data: { message: 'Evidencia entregada al coordinador con éxito.' } });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Download session evidence file (Coordinator / Instructor)
export const downloadSessionEvidence = async (req, res) => {
  try {
    const sessionId = req.params.sessionId || req.params.id;
    const session = await get('SELECT * FROM attendance_sessions WHERE id = ?', [sessionId]);
    if (!session) {
      return res.status(404).json({ error: { code: 'SESSION_NOT_FOUND', message: 'Sesión no encontrada.' } });
    }

    // Verify institution
    if (req.user?.institutionId && session.institution_id !== req.user.institutionId) {
      return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'No tienes acceso a esta sesión.' } });
    }

    // Verify role: Coordinator or creator/assigned instructor
    const userRoles = req.user?.roles || [];
    const isCoord = userRoles.includes('COORDINADOR') || userRoles.includes('COORDINATOR');
    if (!isCoord && req.user?.id) {
      const isCreator = session.created_by === req.user.id;
      const isAssigned = await get(
        'SELECT id FROM instructor_assignments WHERE instructor_id = ? AND unit_id = ?',
        [req.user.id, session.unit_id]
      );
      if (!isCreator && !isAssigned) {
        return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'No estás autorizado para descargar esta evidencia.' } });
      }
    }

    if (!session.evidence_file_data) {
      return res.status(404).json({ error: { code: 'NO_EVIDENCE_ATTACHED', message: 'No hay archivo de evidencia adjunto para esta sesión.' } });
    }

    const fileName = session.evidence_file_name || `evidencia_${sessionId}.xlsx`;
    let validated;
    let bytes;
    try {
      const parsed = parseDataUrlOrBase64(session.evidence_file_data);
      bytes = decodeBase64ToBytes(parsed.base64);
      validated = validateEvidencePayload({
        fileName,
        rawFileData: session.evidence_file_data,
        decodedBytes: bytes,
        declaredMimeOverride: session.evidence_mime_type
      });
    } catch (err) {
      if (err instanceof DomainValidationError) {
        return res.status(err.status).json({ error: { code: err.code, message: err.message } });
      }
      throw err;
    }

    const buffer = Buffer.from(bytes);
    res.setHeader('Content-Type', validated.mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(fileName)}"`);
    res.setHeader('Content-Length', buffer.length);
    return res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Get all sessions / evidences (Coordinator)
export const getCoordEvidences = async (req, res) => {
  try {
    const institutionId = req.user?.institutionId;
    let sql = `
      SELECT 
        s.id,
        s.activated_at,
        s.closed_at,
        s.status,
        s.evidence_submitted,
        s.evidence_submitted_at,
        s.evidence_file_name,
        s.evidence_mime_type,
        s.evidence_file_size,
        u.code as ficha_code,
        u.name as ficha_name,
        u.jornada as jornada,
        COALESCE(p_creator.nombre, p_assigned.nombre, 'Sin asignar') as instructor_name
      FROM attendance_sessions s
      JOIN academic_units u ON s.unit_id = u.id
      LEFT JOIN people p_creator ON s.created_by = p_creator.id
      LEFT JOIN instructor_assignments ia ON ia.unit_id = s.unit_id
      LEFT JOIN people p_assigned ON ia.instructor_id = p_assigned.id
      WHERE 1=1
    `;
    const params = [];

    if (institutionId) {
      sql += ' AND s.institution_id = ?';
      params.push(institutionId);
    }

    sql += ' ORDER BY s.activated_at DESC';

    const sessions = await query(sql, params);
    
    // Deduplicate sessions
    const seen = new Set();
    const uniqueSessions = [];
    for (const s of sessions) {
      if (!seen.has(s.id)) {
        seen.add(s.id);
        uniqueSessions.push(s);
      }
    }

    res.json({ data: uniqueSessions });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Delete student account (Habeas Data compliance per BR-11)
export const deleteStudentAccount = async (req, res) => {
  try {
    const personId = req.user.id;

    if (!personId) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'No se pudo identificar al usuario.' } });
    }

    // 1. Mark enrollments inactive
    await run('UPDATE enrollments SET active = 0 WHERE person_id = ?', [personId]);

    // 2. Anonymize records in attendance_records (remove personal identification but keep record statistics)
    await run(`
      UPDATE attendance_records 
      SET documento = '0000000000', reject_reason = 'Anonimizado por Habeas Data' 
      WHERE person_id = ?
    `, [personId]);

    // 3. Anonymize personal data in people (deterministic synthetic identifiers to preserve UNIQUE constraints and audit trail integrity)
    await run(`
      UPDATE people 
      SET nombre = 'APRENDIZ_ANONIMIZADO',
          email = 'anon_' || id || '@sena.anonymized.local',
          documento = 'ANON_DOC_' || id,
          password = '',
          photo_reference = NULL,
          active = 0
      WHERE id = ?
    `, [personId]);

    await createAuditLog(personId, 'STUDENT_ACCOUNT_ANONYMIZED', 'people', personId, null, {
      status: 'ANONYMIZED'
    }, { ip: req.ip || req.socket.remoteAddress });

    res.json({ data: { message: 'Cuenta y datos personales suprimidos correctamente de acuerdo con la Ley 1581 (Habeas Data).' } });
  } catch (err) {
    console.error('deleteStudentAccount error:', err);
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Accept student terms (Habeas Data compliance)
export const acceptStudentTerms = async (req, res) => {
  try {
    const personId = req.user.id;
    if (!personId) {
      return res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'No se pudo identificar al usuario.' } });
    }

    await run('UPDATE people SET terms_accepted = 1 WHERE id = ?', [personId]);
    res.json({ data: { success: true, message: 'Términos y condiciones aceptados.' } });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};

// Biometric exception handlers removed per ADR-003 (anti-overengineering facial AI).

// ── FASE 1: PUBLIC FICHAS & STUDENT REGISTRATION ─────────────────────────────

// GET /public/fichas (Active academic units for student self-registration)
export const getPublicFichas = async (req, res) => {
  try {
    const fichas = await query(`
      SELECT id, code, name, jornada, modalidad, status 
      FROM academic_units 
      WHERE active = 1 AND (status IS NULL OR status = 'ACTIVE')
      ORDER BY code ASC
    `);
    return res.status(200).json({ data: fichas });
  } catch (err) {
    console.error('getPublicFichas error:', err);
    return res.status(500).json({ error: { code: 'SERVER_ERROR', message: 'Error al consultar fichas activas.' } });
  }
};

// POST /public/student/register (Student self-registration with pre-load anti-takeover)
export const registerStudent = async (req, res) => {
  try {
    const { fichaId, nombre, documento, email, password, termsAccepted } = req.body;

    if (!fichaId || !nombre || !documento || !email || !password) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'Todos los campos son obligatorios.' }
      });
    }

    if (!termsAccepted) {
      return res.status(400).json({
        error: { code: 'INVALID_TERMS', message: 'Debe aceptar la Política de Tratamiento de Datos Personales (Habeas Data).' }
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        error: { code: 'INVALID_PASSWORD', message: 'La contraseña debe tener al menos 6 caracteres.' }
      });
    }

    const cleanDoc = documento.toString().trim().replace(/\D/g, '');
    const cleanEmail = email.toString().trim().toLowerCase();
    const cleanName = sanitizeText(nombre, 120);

    if (!cleanDoc) {
      return res.status(400).json({
        error: { code: 'VALIDATION_ERROR', message: 'El documento no contiene dígitos válidos.' }
      });
    }

    // Verify active ficha
    const ficha = await get(
      "SELECT * FROM academic_units WHERE id = ? AND active = 1 AND (status IS NULL OR status = 'ACTIVE')",
      [fichaId]
    );
    if (!ficha) {
      return res.status(400).json({
        error: { code: 'FICHA_NOT_ACTIVE', message: 'La ficha seleccionada no existe o no se encuentra activa.' }
      });
    }

    // Check existing by doc and by email
    const existingByDoc = await get('SELECT * FROM people WHERE documento = ?', [cleanDoc]);
    const existingByEmail = await get('SELECT * FROM people WHERE LOWER(email) = LOWER(?)', [cleanEmail]);

    let targetPersonId = null;

    if (existingByDoc) {
      // Identity Anti-Takeover rule:
      // If pre-loaded by coordinator, existing email must match cleanEmail
      if (existingByDoc.email && existingByDoc.email.trim().toLowerCase() !== cleanEmail) {
        return res.status(403).json({
          error: {
            code: 'IDENTITY_VERIFICATION_FAILED',
            message: 'El documento ya está registrado con otro correo electrónico. Por seguridad, contacte a su coordinador.'
          }
        });
      }

      // Hash password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);

      // Activate pre-loaded student
      await run(
        `UPDATE people 
         SET nombre = ?, email = ?, password = ?, terms_accepted = 1, active = 1, must_change_password = 0 
         WHERE id = ?`,
        [cleanName, cleanEmail, hashedPassword, existingByDoc.id]
      );

      targetPersonId = existingByDoc.id;

      // Link to ficha in enrollments if not already enrolled
      const existingEnrollment = await get(
        'SELECT * FROM enrollments WHERE unit_id = ? AND person_id = ?',
        [ficha.id, existingByDoc.id]
      );
      if (!existingEnrollment) {
        const enrollId = 'enr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
        await run(
          'INSERT INTO enrollments (id, institution_id, unit_id, person_id, active) VALUES (?, ?, ?, ?, 1)',
          [enrollId, ficha.institution_id, ficha.id, existingByDoc.id]
        );
      } else {
        await run('UPDATE enrollments SET active = 1 WHERE id = ?', [existingEnrollment.id]);
      }

      await createAuditLog(targetPersonId, 'STUDENT_PRELOAD_ACTIVATION', 'people', targetPersonId, null, {
        nombre: cleanName,
        email: cleanEmail,
        fichaId: ficha.id
      }, { ip: req.ip || req.socket.remoteAddress });

    } else {
      // Document is new. Verify email uniqueness
      if (existingByEmail) {
        return res.status(400).json({
          error: {
            code: 'EMAIL_ALREADY_EXISTS',
            message: 'El correo electrónico ya está registrado con otro documento de identidad.'
          }
        });
      }

      const newId = 'person_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
      const rolesJson = JSON.stringify(['APRENDIZ']);

      await run(
        `INSERT INTO people (id, institution_id, documento, email, nombre, roles, password, terms_accepted, active, must_change_password)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1, 0)`,
        [newId, ficha.institution_id, cleanDoc, cleanEmail, cleanName, rolesJson, hashedPassword]
      );

      const enrollId = 'enr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      await run(
        'INSERT INTO enrollments (id, institution_id, unit_id, person_id, active) VALUES (?, ?, ?, ?, 1)',
        [enrollId, ficha.institution_id, ficha.id, newId]
      );

      targetPersonId = newId;

      await createAuditLog(targetPersonId, 'STUDENT_SELF_REGISTRATION', 'people', targetPersonId, null, {
        nombre: cleanName,
        email: cleanEmail,
        documento: cleanDoc,
        fichaId: ficha.id
      }, { ip: req.ip || req.socket.remoteAddress });
    }

    // Generate session JWT
    const tokenPayload = {
      id: targetPersonId,
      institutionId: ficha.institution_id,
      documento: cleanDoc,
      nombre: cleanName,
      roles: ['APRENDIZ']
    };
    const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: '24h' });

    return res.status(201).json({
      data: {
        token,
        person: {
          id: targetPersonId,
          nombre: cleanName,
          documento: cleanDoc,
          email: cleanEmail,
          terms_accepted: 1,
          roles: ['APRENDIZ']
        },
        message: 'Registro de aprendiz completado con éxito.'
      }
    });
  } catch (err) {
    console.error('registerStudent error:', err);
    return res.status(500).json({
      error: { code: 'SERVER_ERROR', message: 'Error interno durante el registro de aprendiz.' }
    });
  }
};

// ── FASE 2: GET STUDENT ACTIVE SESSION ───────────────────────────────────────

// GET /api/student/active-session
export const getStudentActiveSession = async (req, res) => {
  try {
    const studentId = req.user.id;
    const enrollments = await query('SELECT unit_id FROM enrollments WHERE person_id = ? AND active = 1', [studentId]);
    if (!enrollments || enrollments.length === 0) {
      return res.status(200).json({ data: { hasActiveSession: false } });
    }

    const unitIds = enrollments.map(e => e.unit_id);
    const placeholders = unitIds.map(() => '?').join(',');
    const session = await get(`
      SELECT s.id, s.unit_id, s.status, s.room_created_at, s.room_expires_at, s.validation_mode, s.qr_token,
             u.code as unit_code, u.name as unit_name
      FROM attendance_sessions s
      JOIN academic_units u ON s.unit_id = u.id
      WHERE s.unit_id IN (${placeholders}) AND LOWER(s.status) IN ('active', 'open')
      ORDER BY s.room_created_at DESC LIMIT 1
    `, unitIds);

    if (!session) {
      return res.status(200).json({ data: { hasActiveSession: false } });
    }

    // Check if apprentice already checked in
    const checkin = await get('SELECT * FROM attendance_records WHERE session_id = ? AND person_id = ?', [session.id, studentId]);

    const now = new Date();
    const isExpired = session.room_expires_at && now > new Date(session.room_expires_at);

    return res.status(200).json({
      data: {
        hasActiveSession: true,
        isExpired: !!isExpired,
        alreadyCheckedIn: !!checkin,
        checkinRecord: checkin || null,
        session: {
          id: session.id,
          unitId: session.unit_id,
          unitCode: session.unit_code,
          unitName: session.unit_name,
          validationMode: session.validation_mode || 'QR_ONLY',
          createdAt: session.room_created_at,
          expiresAt: session.room_expires_at
        }
      }
    });
  } catch (err) {
    console.error('getStudentActiveSession error:', err);
    return res.status(500).json({ error: { code: 'SERVER_ERROR', message: 'Error consultando sesión activa.' } });
  }
};

// ── AUDIT LOGS CONTROLLER (COORDINADOR) ──────────────────────────────────────
export const getAuditLogs = async (req, res) => {
  try {
    const logs = await query(`
      SELECT a.id, a.actor_id, a.action, a.entity_type, a.entity_id,
             a.before_json, a.after_json, a.metadata_json, a.created_at,
             p.nombre as actor_name, p.documento as actor_doc
      FROM audit_logs a
      LEFT JOIN people p ON a.actor_id = p.id
      ORDER BY a.created_at DESC
      LIMIT 100
    `);
    res.json({ data: logs });
  } catch (err) {
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: err.message } });
  }
};
