# 00 — Prácticas de equipo

## Purpose

This section establishes collaboration standards for
the **SENA Academic Attendance System** (`sena-attendance-system`). It describes how
our team plans, branches, reviews, tests, documents, and secures an application
organized according to the project’s seven-layer architecture.

## Documents

| Document | Answers | Priority |
|---|---|---|
| [definition-of-ready.md](./definition-of-ready.md) | When can an attendance user story enter a sprint? | ⭐ |
| [definition-of-done.md](./definition-of-done.md) | When is an attendance user story finished? | ⭐ |
| [git-conventions.md](./git-conventions.md) | How are branches and commit messages structured? | ⭐ |
| [documentation-rules.md](./documentation-rules.md) | When is an SDD design document complete? | ⭐ |
| [agile-conventions.md](./agile-conventions.md) | What ceremonies run, and what artifacts do they produce? | — |
| [security-policy.md](./security-policy.md) | How are JWT secrets, passwords, and data protected? | — |
| [_template-sprint-retro.md](./_template-sprint-retro.md) | Template for bi-weekly sprint retrospectives | — |

## Out of scope

The team process supports the architecture defined in
[`docs/architecture/n-layer-architecture.md`](../docs/architecture/n-layer-architecture.md).
Distributed-system patterns are outside the scope of this project.

## Verification checklist

- [x] Definition of Ready and Done enforced on all sprint backlog items
- [x] Git conventions strictly followed in commits and PRs
- [x] Security lead assigned and operational audit policies active

---

**Related:** [`00-sdd-guide.md`](../00-sdd-guide.md) · [`documentation-rules.md`](./documentation-rules.md)
