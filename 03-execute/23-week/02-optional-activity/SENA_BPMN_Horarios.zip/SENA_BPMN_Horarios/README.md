# 🏛️ SENA - Sistema de Gestión de Horarios y Ambientes de Formación
> **Ingeniería Inversa Forense, Modelado BPMN 2.0 (ISO/IEC 19510) y Modelo Lógico Global de Datos (Fase 03-Design / Agente A10)**

Repositorio oficial del diseño de arquitectura, procesos de negocio y base de datos relacional para el sistema de asignación de horarios, ambientes e instructores del SENA, derivado a partir del análisis del prototipo funcional (`code-sena/design-software-mockup`).

---

## 📊 Diagrama Entidad-Relación Global (DER)

![Diagrama Entidad-Relacion](DIAGRAMA_MODELO_DATOS_DER.png)

> **Documento Completo de Especificación Lógica**: Consulta [MODELO_DATOS_LOGICO_GLOBAL.md](MODELO_DATOS_LOGICO_GLOBAL.md) para el diccionario de datos por Bounded Contexts, matrices de acceso, PII e invariantes de negocio.

---

## 📁 Estructura del Repositorio

```text
📁 SENA_BPMN_Horarios/
│
├── 📄 README.md                                 # Presentación, matriz de trazabilidad y guía de sustentación
├── 📄 DIAGRAMA_MODELO_DATOS_DER.png             # Diagrama Entidad-Relación Global (DER)
├── 📄 MODELO_DATOS_LOGICO_GLOBAL.md             # Especificación técnica A10 (Glosario, Bounded Contexts, Invariantes)
├── 📄 MODELO_DATOS_RELACIONAL.md                # Referencia relacional y diccionario de datos complementario
├── 📄 schema_sena_horarios.sql                  # Script DDL SQL ejecutable + Población de datos semilla
│
├── 📂 01_Coordinador_Academico/                 # Procesos BPMN 2.0 del rol Coordinador
│   ├── 📄 PROC_C1_Gestion_Validacion_Publicacion_Horarios.bpmn  (Ciclo E2E: Borrador -> Grilla -> Motor de Cruces -> Publicación)
│   ├── 📄 PROC_C2_Consulta_Disponibilidad_Recursos.bpmn         (Filtros fecha/franja -> Ocupación y fichas técnicas)
│   └── 📄 PROC_C3_Revision_Aprobacion_Excepciones_Docentes.bpmn (Bandeja de novedades -> Soporte PDF -> Contingencia)
│
├── 📂 02_Instructor/                            # Procesos BPMN 2.0 del rol Instructor
│   ├── 📄 PROC_I1_Consulta_Horario_Registro_Ejecucion.bpmn      (Calendario semanal -> Drawer de clase -> Marcar estado)
│   ├── 📄 PROC_I2_Solicitud_Excepcion_Disponibilidad.bpmn       (Formulario de novedad -> Adjunto soporte médico/comisión)
│   └── 📄 PROC_I3_Registro_Seguimiento_Academico.bpmn           (Asistencia de aprendices -> Bitácora y alerta de deserción)
│
├── 📂 03_Aprendiz/                              # Procesos BPMN 2.0 del rol Aprendiz
│   ├── 📄 PROC_A1_Consulta_Horario_Propio.bpmn                  (Itinerario de formación -> Detalle de aula, instructor y RAP)
│   └── 📄 PROC_A2_Gestion_Notificaciones.bpmn                   (Bandeja de alertas -> DeepLink a clase reprogramada)
│
├── 📂 04_Director_Centro/                       # Procesos BPMN 2.0 del rol Director de Centro
│   ├── 📄 PROC_D1_Monitoreo_Directivo_KPIs_Desercion.bpmn       (Dashboard institucional -> Semáforo de riesgo -> Drilldown)
│   └── 📄 PROC_D2_Gestion_Usuarios_Matriz_RBAC.bpmn             (Creación de usuarios -> Asignación de rol y sede)
│
└── 📂 05_Administrador_Soporte/                 # Procesos BPMN 2.0 del rol Administrador / Soporte
    ├── 📄 PROC_S1_Generacion_Gestion_Documental.bpmn            (Plantillas TRD -> Compilación asíncrona PDF -> Hash SHA-256)
    └── 📄 PROC_S2_Trazabilidad_Auditoria_Logs.bpmn              (Trazas inmutables append-only -> Modal Diff JSON old/new)
```

---

## 🛡️ Matriz de Trazabilidad: 12 Procesos BPMN 2.0 vs 10 Bounded Contexts

| Proceso BPMN 2.0 | Rol Actor | Bounded Contexts | Tablas de Persistencia |
| :--- | :--- | :--- | :--- |
| **`PROC_C1`: Gestión y Publicación de Horarios** | Coordinador | `scheduling`, `environment`, `actors` | `schedule`, `class_session`, `scheduling_conflict`, `sent_notification`, `audit_record` |
| **`PROC_C2`: Disponibilidad de Recursos** | Coordinador | `environment`, `actors`, `scheduling` | `environment`, `environment_type`, `instructor`, `instructor_exception`, `class_session` |
| **`PROC_C3`: Aprobación de Excepciones** | Coordinador | `actors`, `scheduling`, `notification`| `instructor_exception`, `class_session`, `sent_notification`, `audit_record` |
| **`PROC_I1`: Horario y Ejecución Docente** | Instructor | `scheduling`, `academic`, `environment`| `class_session`, `schedule`, `environment`, `learning_outcome` |
| **`PROC_I2`: Solicitud de Novedad/Excepción** | Instructor | `actors`, `notification` | `instructor_exception` (con `support_file_url`), `sent_notification` |
| **`PROC_I3`: Seguimiento y Asistencia** | Instructor | `monitoring`, `academic` | `tracking_session`, `ficha_tracking`, `generated_alert` |
| **`PROC_A1`: Consulta de Horario Propio** | Aprendiz | `scheduling`, `academic` | `class_session`, `enrollment_ficha`, `learner_enrollment` |
| **`PROC_A2`: Gestión de Notificaciones** | Aprendiz | `notification`, `scheduling` | `sent_notification` (control `is_read` y `deep_link`) |
| **`PROC_D1`: Monitoreo Directivo y Deserción** | Director | `monitoring`, `academic` | `ficha_tracking`, `tracking_session`, `generated_alert` |
| **`PROC_D2`: Matriz RBAC e Identidades** | Director | `iam`, `reference-data` | `app_user`, `app_role`, `user_role`, `campus_sede`, `audit_record` |
| **`PROC_S1`: Gestión Documental TRD** | Soporte | `document`, `scheduling` | `document_template`, `generated_document` (PDF/SHA-256) |
| **`PROC_S2`: Auditoría Forense y Logs** | Soporte | `audit`, `iam` | `audit_record` (Invariante Append-Only, visor diff JSON) |

---

## 🎯 4 Pilares de Defensa Metodológica

1. **Abstracción y Granularidad (ISO/IEC 19510):** Se erradicó el anti-patrón de "wireflows" (diagramar cada botón o modal como proceso huérfano). Cada uno de los 12 procesos modela un ciclo de vida completo de valor de negocio.
2. **Patrón Party-Role / RBAC:** La entidad `Instructor` existe como recurso operativo asignable (con carga horaria y especialidad), mientras que `Coordinador` y `Director` son roles de seguridad gestionados en la matriz `UserRole`.
3. **Ingeniería Inversa Estricta:** Cobertura total de las 53 rutas y pantallas del mockup oficial, sin inventar módulos ajenos al alcance (como juicios RAP de Sofía Plus o excusas médicas de aprendices).
4. **Coherencia Relacional (3NF):** Correspondencia exacta 1 a 1 entre los eventos y tareas de los BPMN con el script DDL (`schema_sena_horarios.sql`) y las tablas de base de datos.