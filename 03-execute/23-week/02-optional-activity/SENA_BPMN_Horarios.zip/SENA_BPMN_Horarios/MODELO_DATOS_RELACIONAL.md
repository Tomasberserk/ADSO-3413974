# 🏛️ SENA - Sistema de Gestión de Horarios y Ambientes de Formación
## Modelo de Datos Relacional (DER) e Ingeniería Inversa Forense

Este documento formaliza la estructura de la base de datos relacional obtenida mediante **ingeniería inversa estricta** sobre las 53 rutas, pantallas, almacenes (`data_mock-data.js`) y controladores del mockup oficial (`code-sena/design-software-mockup`).

---

## 1. Diagrama Entidad-Relación (DER Mermaid)

```mermaid
erDiagram
    %% DOMINIO IAM Y SEGURIDAD
    USUARIOS ||--o{ USUARIOS_ROLES : "tiene asignado"
    ROLES ||--o{ USUARIOS_ROLES : "agrupa"
    SEDES ||--o{ USUARIOS_ROLES : "contextualiza"
    
    USUARIOS {
        varchar id PK
        varchar tipo_documento
        varchar numero_documento UK
        varchar nombres
        varchar apellidos
        varchar email_institucional UK
        varchar password_hash
        varchar mfa_secret
        boolean mfa_enabled
        boolean is_active
        timestamp ultimo_acceso
        timestamp created_at
    }

    ROLES {
        varchar id PK
        varchar codigo UK
        varchar nombre
        text descripcion
    }

    USUARIOS_ROLES {
        varchar id PK
        varchar usuario_id FK
        varchar rol_id FK
        varchar sede_id FK
        varchar resolucion_siga
        boolean is_active
        timestamp asignado_en
    }

    %% DOMINIO GEOGRÁFICO E INSTITUCIONAL
    REGIONALES ||--o{ CENTROS_FORMACION : "contiene"
    CENTROS_FORMACION ||--o{ SEDES : "opera en"

    REGIONALES {
        varchar id PK
        varchar codigo UK
        varchar nombre
        varchar macroregion
    }

    CENTROS_FORMACION {
        varchar id PK
        varchar regional_id FK
        varchar codigo UK
        varchar nombre
        varchar direccion
    }

    SEDES {
        varchar id PK
        varchar centro_id FK
        varchar codigo UK
        varchar nombre
        varchar direccion
        decimal latitud
        decimal longitud
    }

    %% DOMINIO CURRICULAR Y ACADÉMICO (GFPI)
    PROGRAMAS_FORMACION ||--o{ COMPETENCIAS : "estructura"
    COMPETENCIAS ||--o{ RESULTADOS_APRENDIZAJE : "desglosa"
    PROGRAMAS_FORMACION ||--o{ FICHAS_CARACTERIZACION : "origina"
    SEDES ||--o{ FICHAS_CARACTERIZACION : "aloja"

    PROGRAMAS_FORMACION {
        varchar id PK
        varchar codigo_sena UK
        varchar nombre
        integer version
        varchar nivel_formacion
        integer horas_totales
        varchar linea_tecnologica
        varchar red_conocimiento
        boolean is_active
    }

    COMPETENCIAS {
        varchar id PK
        varchar programa_id FK
        varchar codigo_norma
        text denominacion
        integer horas_duracion
    }

    RESULTADOS_APRENDIZAJE {
        varchar id PK
        varchar competencia_id FK
        varchar codigo_rap
        text descripcion
    }

    FICHAS_CARACTERIZACION {
        varchar id PK
        varchar numero_ficha UK
        varchar programa_id FK
        varchar sede_id FK
        varchar jornada
        varchar modalidad
        varchar estado
        integer cupo_aprendices
        date fecha_inicio
        date fecha_fin
    }

    %% DOMINIO DE AMBIENTES E INFRAESTRUCTURA
    TIPOS_AMBIENTE ||--o{ AMBIENTES_FORMACION : "categoriza"
    SEDES ||--o{ AMBIENTES_FORMACION : "ubica"

    TIPOS_AMBIENTE {
        varchar id PK
        varchar codigo UK
        varchar nombre
        text descripcion
    }

    AMBIENTES_FORMACION {
        varchar id PK
        varchar sede_id FK
        varchar tipo_ambiente_id FK
        varchar nombre
        varchar codigo
        integer capacidad_aforo
        varchar ubicacion_bloque
        boolean is_available
        varchar estado_operativo
    }

    %% DOMINIO DE INSTRUCTORES Y DISPONIBILIDAD
    USUARIOS ||--|| INSTRUCTORES : "perfil docente"
    SEDES ||--o{ INSTRUCTORES : "sede base"
    INSTRUCTORES ||--o{ EXCEPCIONES_DISPONIBILIDAD : "radica"
    USUARIOS ||--o{ EXCEPCIONES_DISPONIBILIDAD : "revisa"

    INSTRUCTORES {
        varchar id PK
        varchar usuario_id FK_UK
        varchar area_tematica
        integer horas_maximas_semanales
        varchar sede_principal_id FK
        boolean is_available
    }

    EXCEPCIONES_DISPONIBILIDAD {
        varchar id PK
        varchar instructor_id FK
        varchar tipo_excepcion
        timestamp fecha_inicio
        timestamp fecha_fin
        text motivo
        varchar soporte_url
        varchar estado
        varchar revisado_por FK
        timestamp fecha_revision
        text justificacion_revision
    }

    %% DOMINIO DE HORARIOS Y SESIONES
    FICHAS_CARACTERIZACION ||--o{ HORARIOS : "planifica"
    USUARIOS ||--o{ HORARIOS : "publica"
    HORARIOS ||--o{ SESIONES_CLASE : "contiene"
    RESULTADOS_APRENDIZAJE ||--o{ SESIONES_CLASE : "imparte"
    INSTRUCTORES ||--o{ SESIONES_CLASE : "dicta"
    AMBIENTES_FORMACION ||--o{ SESIONES_CLASE : "aloja"
    HORARIOS ||--o{ CONFLICTOS_PROGRAMACION : "registra"
    SESIONES_CLASE ||--o{ CONFLICTOS_PROGRAMACION : "involucrada A"
    SESIONES_CLASE ||--o{ CONFLICTOS_PROGRAMACION : "involucrada B"
    USUARIOS ||--o{ CONFLICTOS_PROGRAMACION : "resuelve"

    HORARIOS {
        varchar id PK
        varchar ficha_id FK
        varchar periodo_academico
        varchar nombre_descriptivo
        varchar estado
        date vigencia_inicio
        date vigencia_fin
        varchar publicado_por FK
        timestamp fecha_publicacion
        timestamp created_at
        timestamp updated_at
    }

    SESIONES_CLASE {
        varchar id PK
        varchar horario_id FK
        varchar resultado_aprendizaje_id FK
        varchar instructor_id FK
        varchar ambiente_id FK
        varchar dia_semana
        date fecha_especifica
        time hora_inicio
        time hora_fin
        varchar estado
    }

    CONFLICTOS_PROGRAMACION {
        varchar id PK
        varchar horario_id FK
        varchar sesion_a_id FK
        varchar sesion_b_id FK
        varchar tipo_conflicto
        varchar severidad
        boolean is_blocking
        text descripcion
        boolean is_resolved
        varchar resuelto_por FK
        timestamp fecha_resolucion
        text motivo_resolucion
    }

    %% DOMINIO DE SEGUIMIENTO ACADÉMICO Y MONITOREO
    FICHAS_CARACTERIZACION ||--o{ SEGUIMIENTO_FICHA : "evalua"
    SESIONES_CLASE ||--o{ SEGUIMIENTO_FICHA : "ejecuta"
    INSTRUCTORES ||--o{ SEGUIMIENTO_FICHA : "asienta"
    SEGUIMIENTO_FICHA ||--o{ ALERTAS_MONITOREO : "dispara"

    SEGUIMIENTO_FICHA {
        varchar id PK
        varchar ficha_id FK
        varchar sesion_clase_id FK
        varchar instructor_id FK
        date fecha_registro
        integer total_aprendices_matriculados
        integer total_aprendices_asistentes
        decimal porcentaje_asistencia
        text observaciones_pedagogicas
        varchar tema_desarrollado
    }

    ALERTAS_MONITOREO {
        varchar id PK
        varchar tipo_alerta
        varchar entidad_origen
        varchar entidad_origen_id
        varchar nivel_riesgo
        varchar destinatario_rol
        boolean is_dismissed
        timestamp created_at
    }

    %% DOMINIO DE NOTIFICACIONES, DOCUMENTOS Y AUDITORÍA
    USUARIOS ||--o{ NOTIFICACIONES : "recibe"
    HORARIOS ||--o{ NOTIFICACIONES : "referencia"
    PLANTILLAS_DOCUMENTOS ||--o{ DOCUMENTOS_GENERADOS : "instancia"
    USUARIOS ||--o{ DOCUMENTOS_GENERADOS : "emite"
    USUARIOS ||--o{ REGISTROS_AUDITORIA : "ejecuta accion"

    NOTIFICACIONES {
        varchar id PK
        varchar usuario_destinatario_id FK
        varchar schedule_id FK
        varchar asunto
        text mensaje_resumen
        varchar categoria
        varchar prioridad
        varchar deep_link
        boolean is_read
        varchar status_envio
        timestamp created_at
    }

    PLANTILLAS_DOCUMENTOS {
        varchar id PK
        varchar codigo UK
        varchar nombre
        varchar tipo_salida
        integer version_actual
        varchar estado_version
        boolean is_active
        timestamp updated_at
    }

    DOCUMENTOS_GENERADOS {
        varchar id PK
        varchar plantilla_id FK
        varchar titulo
        varchar dominio
        varchar entidad_asociada_id
        varchar archivo_pdf_url
        varchar hash_sha256
        integer version
        varchar estado_generacion
        varchar generado_por FK
        timestamp created_at
    }

    REGISTROS_AUDITORIA {
        varchar id PK
        varchar evento
        varchar nombre_entidad
        varchar entidad_id
        varchar actor_usuario_id FK
        varchar actor_nombre
        varchar servicio_origen
        json old_value_json
        json new_value_json
        varchar resultado
        varchar ip_address
        timestamp created_at
    }
```

---

## 2. Diccionario de Datos por Dominios de Negocio

### 👤 Dominio 1: IAM, Usuarios y Matriz RBAC
* **`usuarios`**: Almacena las identidades institucionales (aprendices, instructores, coordinadores, directores, soporte).
  * Invariantes: `email_institucional` debe terminar en `@sena.edu.co` o `@soy.sena.edu.co`.
* **`roles`**: Catálogo canónico de perfiles (`COORDINATOR`, `INSTRUCTOR`, `LEARNER`, `CENTER_DIRECTOR`, `ADMIN_STAFF`).
* **`usuarios_roles`**: Tabla intermedia que asigna roles a usuarios por sede específica y resolución rectoral.

### 🏢 Dominio 2: Geografía y Sedes Institucionales
* **`regionales`**: Regionales SENA (ej: Antioquia, Cundinamarca, Valle).
* **`centros_formacion`**: Centros de formación adscritos a una regional.
* **`sedes`**: Sedes físicas con geolocalización (`latitud`, `longitud`) requerida para calcular el conflicto de traslado inter-sedes (`INSTRUCTOR_TRAVEL_CONFLICT`).

### 📚 Dominio 3: Catálogo Curricular GFPI
* **`programas_formacion`**: Programas de formación técnica y tecnológica con su versión y duración.
* **`competencias`**: Normas de competencia laboral asociadas a cada programa.
* **`resultados_aprendizaje` (RAPs)**: Resultados de aprendizaje evaluables impartidos en cada sesión de clase.
* **`fichas_caracterizacion`**: Grupos de aprendices matriculados en un programa, jornada y modalidad específica.

### 🏛️ Dominio 4: Ambientes e Infraestructura
* **`tipos_ambiente`**: Tipologías de espacio (Laboratorio, Aula, Taller).
* **`ambientes_formacion`**: Espacios físicos reales con aforo máximo, bloque y estado operativo (mantenimiento / disponible).

### 👨‍🏫 Dominio 5: Instructores y Excepciones de Disponibilidad
* **`instructores`**: Perfil docente con horas máximas semanales (36 a 40 h) y especialidad técnica.
* **`excepciones_disponibilidad`**: Novedades e incapacidades radicadas por el instructor con soporte documental (PDF/JPG) para aprobación del coordinador.

### 📅 Dominio 6: Horarios, Sesiones y Motor de Conflictos
* **`horarios`**: Cabecera de programación trimestral de una ficha (`DRAFT`, `UNDER_REVIEW`, `PUBLISHED`, `ARCHIVED`).
* **`sesiones_clase`**: Asignación atómica de Franja + Día + Ambiente + Instructor + RAP.
* **`conflictos_programacion`**: Registro de inconsistencias detectadas por el motor con severidad, bloqueo y auditoría de resolución.

### 📊 Dominio 7: Seguimiento Pedagógico y Monitoreo Directivo (KPIs)
* **`seguimiento_ficha`**: Bitácora de asistencia y tema por sesión ejecutada.
* **`alertas_monitoreo`**: Alertas tempranas generadas automáticamente si la asistencia desciende del 80% (Semáforo de Deserción).

### 📄 Dominio 8: Trazabilidad, Documentos y Auditoría Inmutable
* **`notificaciones`**: Alertas accionables con DeepLink y control de lectura (`is_read`).
* **`plantillas_documentos`**: Catálogo de plantillas oficiales con versionamiento TRD.
* **`documentos_generados`**: Archivo digital de reportes PDF con estampado de tiempo y hash SHA-256.
* **`registros_auditoria`**: Trazas inmutables tipo append-only con visor de diferencias JSON (`old_value_json` vs `new_value_json`).

---

## 3. Matriz de Trazabilidad: 12 Procesos BPMN 2.0 vs 20 Tablas Relacionales

| Proceso BPMN 2.0 | Tablas Principales que Lee / Escribe |
| :--- | :--- |
| **PROC_C1: Gestión, Validación y Publicación de Horarios** | `horarios`, `sesiones_clase`, `conflictos_programacion`, `ambientes_formacion`, `instructores`, `notificaciones`, `registros_auditoria` |
| **PROC_C2: Consulta de Disponibilidad de Recursos** | `ambientes_formacion`, `tipos_ambiente`, `instructores`, `sesiones_clase`, `excepciones_disponibilidad` |
| **PROC_C3: Revisión y Aprobación de Excepciones Docentes** | `excepciones_disponibilidad`, `instructores`, `sesiones_clase`, `notificaciones`, `registros_auditoria` |
| **PROC_I1: Consulta de Horario y Registro de Ejecución** | `sesiones_clase`, `horarios`, `ambientes_formacion`, `resultados_aprendizaje`, `instructores` |
| **PROC_I2: Solicitud de Excepción de Disponibilidad** | `excepciones_disponibilidad`, `instructores`, `notificaciones` |
| **PROC_I3: Registro de Seguimiento Académico y Asistencia** | `seguimiento_ficha`, `sesiones_clase`, `fichas_caracterizacion`, `alertas_monitoreo` |
| **PROC_A1: Consulta de Horario Propio** | `horarios`, `sesiones_clase`, `ambientes_formacion`, `instructores`, `resultados_aprendizaje` |
| **PROC_A2: Gestión y Lectura de Notificaciones** | `notificaciones`, `sesiones_clase`, `horarios` |
| **PROC_D1: Monitoreo Directivo y KPIs de Deserción** | `seguimiento_ficha`, `alertas_monitoreo`, `fichas_caracterizacion`, `horarios`, `sesiones_clase` |
| **PROC_D2: Gestión de Identidades y Matriz RBAC** | `usuarios`, `roles`, `usuarios_roles`, `sedes`, `registros_auditoria` |
| **PROC_S1: Generación y Gestión Documental** | `plantillas_documentos`, `documentos_generados`, `horarios`, `fichas_caracterizacion`, `usuarios` |
| **PROC_S2: Trazabilidad, Logs y Auditoría** | `registros_auditoria`, `usuarios` |