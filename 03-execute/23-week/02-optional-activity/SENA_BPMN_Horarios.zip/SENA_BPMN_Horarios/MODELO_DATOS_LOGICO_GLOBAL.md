# 🏛️ Modelo de Datos Lógico Global — SENA Gestión de Horarios y Ambientes

> **Fase**: 03-Design | **Especificación**: Agente A10 | **Estado**: 🟢 Aprobado / Canónico  
> **Origen**: Ingeniería Inversa Forense sobre el Mockup Oficial (`code-sena/design-software-mockup`) y Catálogo de 12 Procesos BPMN 2.0 (ISO/IEC 19510).  
> **Regla de Naming**: Entidades y atributos en **inglés, singular, snake_case, ASCII**. Toda descripción funcional y glosario en español SENA.

---

## 1. Glosario — Lenguaje Ubicuo (Ubiquitous Language)

| Término (Inglés / BD) | Término (Español SENA) | Definición y Alcance de Negocio |
| :--- | :--- | :--- |
| `Regional` | Regional SENA | División administrativa por departamento (ej: Antioquia, Cundinamarca). |
| `TrainingCenter` | Centro de Formación | Unidad operativa donde se imparte formación profesional. |
| `CampusSede` | Sede Física | Instalación física georreferenciada con coordenadas para cálculo de traslados. |
| `TrainingProgram` | Programa de Formación | Diseño curricular formal (ej: Análisis y Desarrollo de Software - ADSO). |
| `Competency` | Competencia Laboral | Unidad curricular de desempeño que desarrolla el aprendiz. |
| `LearningOutcome` | Resultado de Aprendizaje (RAP)| Subunidad evaluable de una competencia asignada a cada clase. |
| `EnrollmentFicha` | Ficha de Caracterización | Cohorte o grupo de aprendices asignados a un programa y jornada. |
| `LearnerEnrollment` | Inscripción de Aprendiz | Vinculación individual del aprendiz a una ficha activa. |
| `EnvironmentType` | Tipo de Ambiente | Categoría técnica de espacio formativo (Laboratorio, Aula, Taller). |
| `Environment` | Ambiente de Formación | Espacio físico dotado con aforo y equipamiento para clases. |
| `Instructor` | Instructor Formador | Docente vinculado con perfil técnico y límite semanal de horas (36-40h). |
| `InstructorException`| Excepción de Disponibilidad | Solicitud de indisponibilidad docente radicada con soporte PDF (incapacidad/comisión). |
| `Schedule` | Horario Académico | Agregado raíz que contiene la planificación trimestral de una ficha. |
| `TimeSlot` | Franja Horaria | Bloque horario recurrente (ej: Lunes 07:00–10:00). |
| `ClassSession` | Sesión de Clase | Asignación atómica: Ficha + Franja + Instructor + Ambiente + RAP. |
| `SchedulingConflict`| Conflicto de Programación | Inconsistencia detectada por el motor (6 tipos canónicos) con severidad y bloqueo. |
| `FichaTracking` | Seguimiento de Ficha | Bitácora y agregador de cumplimiento curricular de la ficha. |
| `TrackingSession` | Sesión de Seguimiento | Registro puntual de asistencia de aprendices y tema impartido por clase. |
| `GeneratedAlert` | Alerta Temprana de Deserción| Alerta automática disparada si la asistencia desciende del 80%. |
| `SentNotification` | Notificación Accionable | Alerta con DeepLink a la sesión y bandera de lectura (`is_read`). |
| `DocumentTemplate` | Plantilla de Documento | Estructura TRD oficial para renderizado PDF (ej: Constancia, Reporte). |
| `GeneratedDocument` | Documento Generado | Archivo PDF inmutable emitido con hash SHA-256 y firma digital. |
| `AuditRecord` | Registro de Auditoría | Traza inmutable (solo INSERT) con visor de diferencias JSON old/new. |

---

## 2. Diagrama Entidad-Relación Global (Mermaid DER)

```mermaid
erDiagram
    %% IAM & SEGURIDAD
    User ||--o{ UserRole : "has assigned"
    Role ||--o{ UserRole : "groups"
    CampusSede ||--o{ UserRole : "contextualizes"

    %% GEOGRAFIA INSTITUCIONAL
    Regional ||--o{ TrainingCenter : "administers"
    TrainingCenter ||--o{ CampusSede : "operates"

    %% CURRICULO GFPI
    TrainingProgram ||--o{ Competency : "structures"
    Competency ||--o{ LearningOutcome : "breaks down"
    TrainingProgram ||--o{ EnrollmentFicha : "instantiates"
    CampusSede ||--o{ EnrollmentFicha : "hosts"
    EnrollmentFicha ||--o{ LearnerEnrollment : "enrolls"
    User ||--o{ LearnerEnrollment : "is enrolled"

    %% AMBIENTES E INFRAESTRUCTURA
    EnvironmentType ||--o{ Environment : "categorizes"
    CampusSede ||--o{ Environment : "locates"

    %% INSTRUCTORES Y NOVEDADES
    User ||--|| Instructor : "teacher profile"
    CampusSede ||--o{ Instructor : "primary base"
    Instructor ||--o{ InstructorException : "files"
    User ||--o{ InstructorException : "reviews"

    %% HORARIOS Y MOTOR DE CONFLICTOS
    EnrollmentFicha ||--o{ Schedule : "schedules"
    User ||--o{ Schedule : "publishes"
    Schedule ||--o{ ClassSession : "contains"
    LearningOutcome ||--o{ ClassSession : "delivers"
    Instructor ||--o{ ClassSession : "teaches"
    Environment ||--o{ ClassSession : "hosts"
    TimeSlot ||--o{ ClassSession : "timed by"
    Schedule ||--o{ SchedulingConflict : "detects"
    ClassSession ||--o{ SchedulingConflict : "involved session A"
    ClassSession ||--o{ SchedulingConflict : "involved session B"
    User ||--o{ SchedulingConflict : "resolves"

    %% SEGUIMIENTO, ASISTENCIA Y MONITOREO
    EnrollmentFicha ||--o{ FichaTracking : "tracks"
    FichaTracking ||--o{ TrackingSession : "records"
    ClassSession ||--o{ TrackingSession : "executes"
    Instructor ||--o{ TrackingSession : "registers"
    FichaTracking ||--o{ GeneratedAlert : "triggers"

    %% DOCUMENTOS, NOTIFICACIONES Y AUDITORIA
    User ||--o{ SentNotification : "receives"
    Schedule ||--o{ SentNotification : "references"
    DocumentTemplate ||--o{ GeneratedDocument : "renders"
    User ||--o{ GeneratedDocument : "emits"
    User ||--o{ AuditRecord : "triggers event"
```

---

## 3. Modelo Lógico por Bounded Contexts (Microservicios)

### 🔐 Contexto 1: `iam-service` (Identidad, Accesos y Matriz RBAC)

#### `User`
Cuenta de acceso institucional al sistema.

| Atributo | Tipo | Restricciones | PII | Descripción |
| :--- | :--- | :--- | :---: | :--- |
| `id` | UUID | PK, NOT NULL | — | Identificador único universal. |
| `document_type` | VARCHAR(10) | NOT NULL, DEFAULT 'CC' | ✓ | Tipo de documento (CC, TI, CE, PEP). |
| `document_number` | VARCHAR(20) | UNIQUE, NOT NULL | ✓ | Número de identificación oficial. |
| `full_name` | VARCHAR(200) | NOT NULL | ✓ | Nombres y apellidos completos. |
| `institutional_email`| VARCHAR(255) | UNIQUE, NOT NULL | ✓ | Correo @sena.edu.co o @soy.sena.edu.co. |
| `password_hash` | VARCHAR(255) | NOT NULL | — | Hash seguro de contraseña (Argon2id/Bcrypt). |
| `mfa_secret` | VARCHAR(64) | NULLABLE | — | Semilla TOTP para segundo factor. |
| `mfa_enabled` | BOOLEAN | NOT NULL, DEFAULT FALSE | — | Estado de activación de MFA. |
| `is_active` | BOOLEAN | NOT NULL, DEFAULT TRUE | — | Estado técnico de habilitación. |
| `last_access_at` | TIMESTAMPTZ | NULLABLE | — | Estampa de último inicio de sesión exitoso. |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | — | Fecha y hora de creación de la cuenta. |

#### `Role`
Catálogo de perfiles RBAC canónicos.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador del rol. |
| `code` | VARCHAR(30) | UNIQUE, NOT NULL | Código: `COORDINATOR`, `INSTRUCTOR`, `LEARNER`, `CENTER_DIRECTOR`, `ADMIN_STAFF`. |
| `name` | VARCHAR(80) | NOT NULL | Nombre legible del perfil. |
| `description` | TEXT | NULLABLE | Alcance funcional del rol en el sistema. |

#### `UserRole`
Asignación contextual de un rol a un usuario por sede física.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la asignación. |
| `user_id` | UUID | FK -> `User.id`, NOT NULL | Usuario al que se le otorga el perfil. |
| `role_id` | UUID | FK -> `Role.id`, NOT NULL | Perfil concedido. |
| `campus_sede_id` | UUID | FK -> `CampusSede.id`, NULLABLE | Sede de alcance (null = alcance global directivo). |
| `siga_resolution` | VARCHAR(100) | NULLABLE | Número de resolución rectoral de nombramiento. |
| `is_active` | BOOLEAN | NOT NULL, DEFAULT TRUE | Habilitación de la asignación. |
| `assigned_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Momento de la asignación. |

---

### 🌐 Contexto 2: `reference-data-service` (Geografía y Catálogos Maestros)

#### `Regional`
División departamental del SENA.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la regional. |
| `code` | VARCHAR(20) | UNIQUE, NOT NULL | Código interno (ej: `REG-ANT`). |
| `name` | VARCHAR(100) | NOT NULL | Nombre (ej: Regional Antioquia). |
| `macroregion` | VARCHAR(50) | NOT NULL | Zona macro (Suroccidente, Centro Oriente, etc.). |

#### `TrainingCenter`
Centro de Formación profesional adscrito a una regional.

| Atributo | Tipo | Restricciones | PII | Descripción |
| :--- | :--- | :--- | :---: | :--- |
| `id` | UUID | PK | — | Identificador del centro. |
| `regional_id` | UUID | FK -> `Regional.id`, NOT NULL | — | Regional a la que pertenece. |
| `code` | VARCHAR(20) | UNIQUE, NOT NULL | — | Código numérico SENA (ej: `9204`). |
| `name` | VARCHAR(150) | NOT NULL | — | Denominación del Centro de Formación. |
| `address` | VARCHAR(200) | NULLABLE | — | Dirección principal del centro. |

#### `CampusSede`
Instalación física georreferenciada requerida para calcular traslados inter-sedes.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la sede. |
| `training_center_id`| UUID | FK -> `TrainingCenter.id`, NOT NULL | Centro al que pertenece la sede. |
| `code` | VARCHAR(20) | UNIQUE, NOT NULL | Código de la sede (ej: `SEDE-NORTE`). |
| `name` | VARCHAR(100) | NOT NULL | Denominación física (ej: Sede Norte Medellín). |
| `address` | VARCHAR(200) | NULLABLE | Dirección física de acceso. |
| `latitude` | DECIMAL(10,8)| NOT NULL | Latitud para cálculo de tiempo de desplazamiento. |
| `longitude` | DECIMAL(11,8)| NOT NULL | Longitud para cálculo de tiempo de desplazamiento. |

---

### 📚 Contexto 3: `academic-management-service` (Currículo y Fichas GFPI)

#### `TrainingProgram`
Diseño curricular oficial aprobado por la Dirección de Formación.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador del programa. |
| `program_code` | VARCHAR(20) | UNIQUE, NOT NULL | Código oficial SENA (ej: `233104`). |
| `name` | VARCHAR(200) | NOT NULL | Nombre del programa de formación. |
| `version` | INTEGER | NOT NULL, DEFAULT 1 | Versión del diseño curricular (ej: 104). |
| `training_level` | ENUM | NOT NULL | `OPERATOR`, `TECHNICIAN`, `TECHNOLOGIST`. |
| `total_hours` | INTEGER | NOT NULL | Total de horas de formación lectiva/productiva. |
| `tech_line` | VARCHAR(100) | NULLABLE | Línea tecnológica (ej: `LT-TIC`). |
| `knowledge_network`| VARCHAR(100)| NULLABLE | Red de conocimiento (ej: `RC-PROG`). |
| `is_active` | BOOLEAN | NOT NULL, DEFAULT TRUE | Disponibilidad para oferta. |

#### `Competency`
Unidad de competencia laboral dentro del programa.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la competencia. |
| `program_id` | UUID | FK -> `TrainingProgram.id`, NOT NULL | Programa que contiene la competencia. |
| `sena_code` | VARCHAR(30) | NOT NULL | Código de norma de competencia laboral. |
| `denomination` | TEXT | NOT NULL | Texto descriptivo de la competencia. |
| `duration_hours` | INTEGER | NOT NULL | Duración pedagógica en horas. |

#### `LearningOutcome`
Resultado de Aprendizaje (RAP) evaluable asignado a las clases.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador del RAP. |
| `competency_id` | UUID | FK -> `Competency.id`, NOT NULL | Competencia de la que se desprende. |
| `rap_code` | VARCHAR(30) | NOT NULL | Código interno del resultado (ej: `RA-01`). |
| `description` | TEXT | NOT NULL | Logro pedagógico a evaluar en la sesión. |

#### `EnrollmentFicha`
Grupo o cohorte de aprendices en ejecución académica.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la ficha. |
| `ficha_number` | VARCHAR(20) | UNIQUE, NOT NULL | Número de ficha institucional (ej: `2874412`). |
| `program_id` | UUID | FK -> `TrainingProgram.id`, NOT NULL | Programa de formación impartido. |
| `campus_sede_id` | UUID | FK -> `CampusSede.id`, NOT NULL | Sede física donde opera la ficha. |
| `shift` | ENUM | NOT NULL | Jornada: `Diurna`, `Nocturna`, `Mixta`, `Madrugada`. |
| `modality` | ENUM | NOT NULL | Modalidad: `Presencial`, `Virtual`, `Híbrida`. |
| `status` | ENUM | NOT NULL | `INDUCTION`, `EXECUTION`, `PRODUCTIVE_STAGE`, `COMPLETED`, `CANCELLED`. |
| `learner_capacity`| INTEGER | NOT NULL, DEFAULT 30 | Cupo máximo de aprendices matriculados. |
| `start_date` | DATE | NOT NULL | Fecha de inicio de la etapa lectiva. |
| `expected_end_date`| DATE | NULLABLE | Fecha esperada de certificación. |

#### `LearnerEnrollment`
Matrícula individual de un aprendiz dentro de una ficha.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la matrícula. |
| `user_id` | UUID | FK -> `User.id`, NOT NULL | Usuario aprendiz matriculado. |
| `ficha_id` | UUID | FK -> `EnrollmentFicha.id`, NOT NULL | Ficha a la que pertenece. |
| `enrollment_status`| ENUM | NOT NULL | `ACTIVE`, `CANCELLED`, `DROPOUT`, `TRANSFERRED`. |
| `enrolled_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Fecha y hora de asentamiento de matrícula. |

---

### 🏛️ Contexto 4: `training-environment-service` (Ambientes y Recursos)

#### `EnvironmentType`
Tipología del espacio físico formativo.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador del tipo de ambiente. |
| `code` | VARCHAR(30) | UNIQUE, NOT NULL | Código técnico (`LAB`, `AULA`, `TALLER`). |
| `name` | VARCHAR(80) | NOT NULL | Nombre legible (Laboratorio, Aula, Taller). |
| `description` | TEXT | NULLABLE | Descripción del equipamiento estándar. |

#### `Environment`
Espacio físico donde ocurren las clases presenciales.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador del ambiente. |
| `campus_sede_id` | UUID | FK -> `CampusSede.id`, NOT NULL | Sede física donde se ubica el aula. |
| `environment_type_id`| UUID| FK -> `EnvironmentType.id`, NOT NULL | Tipo de espacio formativo. |
| `name` | VARCHAR(100) | NOT NULL | Nombre del ambiente (ej: Laboratorio A-204). |
| `code` | VARCHAR(30) | NULLABLE | Código de placa de inventario. |
| `capacity` | INTEGER | NOT NULL, DEFAULT 30 | Aforo máximo de personas permitidas. |
| `block_location` | VARCHAR(100) | NULLABLE | Ubicación física (ej: Bloque A, piso 2). |
| `is_available` | BOOLEAN | NOT NULL, DEFAULT TRUE | Habilitación técnica para programación. |
| `operational_status`| ENUM | NOT NULL, DEFAULT 'OPERATIONAL'| `OPERATIONAL`, `MAINTENANCE`, `OUT_OF_SERVICE`. |

---

### 👨‍🏫 Contexto 5: `actors-service` (Instructores y Novedades Docentes)

#### `Instructor`
Perfil docente con parametrización de carga horaria semanal.

| Atributo | Tipo | Restricciones | PII | Descripción |
| :--- | :--- | :--- | :---: | :--- |
| `id` | UUID | PK | — | Identificador del perfil docente. |
| `user_id` | UUID | FK -> `User.id`, UNIQUE, NOT NULL | — | Identidad institucional asociada. |
| `thematic_area` | VARCHAR(100) | NOT NULL | — | Especialidad técnica (ej: Software, Calidad). |
| `max_hours_per_week`| INTEGER | NOT NULL, DEFAULT 40 | — | Límite legal semanal de horas cátedra (36/40h). |
| `primary_sede_id`| UUID | FK -> `CampusSede.id`, NOT NULL | — | Sede física habitual de trabajo. |
| `is_available` | BOOLEAN | NOT NULL, DEFAULT TRUE | — | Disponibilidad activa para franjas. |

#### `InstructorException`
Novedad o indisponibilidad temporal radicada con soporte documental (PDF/JPG).

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la excepción. |
| `instructor_id` | UUID | FK -> `Instructor.id`, NOT NULL | Instructor que radica la novedad. |
| `exception_type` | ENUM | NOT NULL | `INCAPACIDAD_MEDICA`, `COMISION_SERVICIO`, `CAPACITACION`, `PERMISO_PERSONAL`. |
| `start_datetime` | TIMESTAMPTZ | NOT NULL | Fecha y hora de inicio de la indisponibilidad. |
| `end_datetime` | TIMESTAMPTZ | NOT NULL | Fecha y hora de culminación. |
| `reason` | TEXT | NOT NULL | Justificación médica o administrativa. |
| `support_file_url`| VARCHAR(255)| NULLABLE | Enlace seguro al soporte adjunto (PDF/JPG). |
| `status` | ENUM | NOT NULL, DEFAULT 'PENDIENTE'| `PENDIENTE_APROBACION`, `APROBADA`, `RECHAZADA`. |
| `reviewed_by` | UUID | FK -> `User.id`, NULLABLE | Coordinador que aprueba/rechaza. |
| `reviewed_at` | TIMESTAMPTZ | NULLABLE | Fecha de decisión. |
| `review_notes` | TEXT | NULLABLE | Motivo de aprobación o rechazo institucional. |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Fecha de radicación. |

---

### 📅 Contexto 6: `scheduling-service` (Horarios, Grilla y Motor de Conflictos)

#### `Schedule`
Agregado raíz del horario trimestral por ficha.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador único del horario. |
| `ficha_id` | UUID | FK -> `EnrollmentFicha.id`, NOT NULL | Ficha académica asignada. |
| `academic_period`| VARCHAR(20) | NOT NULL | Período académico (ej: `2026-1`, `2026-2`). |
| `name` | VARCHAR(150) | NOT NULL | Título del horario (ej: ADSO — Trimestre III). |
| `status` | ENUM | NOT NULL, DEFAULT 'DRAFT' | `DRAFT`, `UNDER_REVIEW`, `PUBLISHED`, `ARCHIVED`. |
| `effective_start` | DATE | NULLABLE | Fecha de inicio de vigencia de las clases. |
| `effective_end` | DATE | NULLABLE | Fecha de fin de vigencia de las clases. |
| `published_by` | UUID | FK -> `User.id`, NULLABLE | Coordinador que congeló la versión oficial. |
| `published_at` | TIMESTAMPTZ | NULLABLE | Timestamp exacto de publicación oficial. |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Fecha de creación del borrador. |
| `updated_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Última modificación de sesiones. |

*Invariante de Dominio*: Una vez `status = 'PUBLISHED'`, el horario se congela en modo lectura. Cualquier ajuste genera una nueva versión o pasa por el flujo de contingencia `PROC_C3`.

#### `TimeSlot`
Definición de franjas horarias parametrizables.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la franja. |
| `name` | VARCHAR(50) | NOT NULL | Nombre de la franja (ej: `07:00–10:00`, `10:00–13:00`). |
| `start_time` | TIME | NOT NULL | Hora inicial de la sesión. |
| `end_time` | TIME | NOT NULL | Hora final de la sesión. |

#### `ClassSession`
Sesión de clase formativa individual en la grilla semanal.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador único de la sesión. |
| `schedule_id` | UUID | FK -> `Schedule.id`, NOT NULL | Horario al que pertenece la sesión. |
| `learning_outcome_id`| UUID| FK -> `LearningOutcome.id`, NOT NULL | RAP curricular impartido en la franja. |
| `instructor_id` | UUID | FK -> `Instructor.id`, NOT NULL | Instructor asignado a impartir la clase. |
| `environment_id`| UUID | FK -> `Environment.id`, NOT NULL | Ambiente formativo donde se ejecuta la clase. |
| `time_slot_id` | UUID | FK -> `TimeSlot.id`, NULLABLE | Franja horaria asignada. |
| `day_of_week` | ENUM | NOT NULL | `Lunes`, `Martes`, `Miércoles`, `Jueves`, `Viernes`, `Sábado`. |
| `specific_date` | DATE | NOT NULL | Fecha calendario de la sesión. |
| `start_time` | TIME | NOT NULL | Hora de inicio programada. |
| `end_time` | TIME | NOT NULL | Hora de culminación programada. |
| `status` | ENUM | NOT NULL, DEFAULT 'ACTIVE' | `ACTIVE`, `EXECUTED`, `CANCELLED`, `RESCHEDULED`. |

#### `SchedulingConflict`
Registro de inconsistencias detectadas por el motor de validación.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador del conflicto detectado. |
| `schedule_id` | UUID | FK -> `Schedule.id`, NOT NULL | Horario en el cual ocurre el conflicto. |
| `session_a_id` | UUID | FK -> `ClassSession.id`, NOT NULL | Primera sesión involucrada en la inconsistencia. |
| `session_b_id` | UUID | FK -> `ClassSession.id`, NULLABLE | Segunda sesión en choque (si aplica). |
| `conflict_type` | ENUM | NOT NULL | Ver catálogo de 6 tipos canónicos abajo. |
| `severity` | ENUM | NOT NULL | `HIGH` (Bloqueante), `MEDIUM`, `LOW`. |
| `is_blocking` | BOOLEAN | NOT NULL, DEFAULT TRUE | Si es TRUE, impide presionar "Publicar Horario". |
| `description` | TEXT | NOT NULL | Explicación técnica detallada del cruce. |
| `is_resolved` | BOOLEAN | NOT NULL, DEFAULT FALSE | Estado de resolución o justificación. |
| `resolved_by` | UUID | FK -> `User.id`, NULLABLE | Coordinador que resolvió o justificó el cruce. |
| `resolved_at` | TIMESTAMPTZ | NULLABLE | Fecha y hora de resolución auditada. |
| `resolution_reason`| TEXT| NULLABLE | Justificación técnica registrada en `?modal=resolve`. |

*Catálogo Canónico de Tipos de Conflicto en el Motor (`conflict_type`)*:
1. `INSTRUCTOR_DOUBLE_BOOKED`: Mismo instructor asignado a dos sesiones en franjas solapadas.
2. `ENVIRONMENT_DOUBLE_BOOKED`: Mismo ambiente físico ocupado por dos fichas al mismo tiempo.
3. `SESSIONS_OVERLAP`: Solapamiento de sesiones de la misma ficha en franjas coincidentes.
4. `ENVIRONMENT_MAINTENANCE`: Sesión programada en un ambiente bloqueado por mantenimiento.
5. `INSTRUCTOR_TRAVEL_CONFLICT`: Tiempo de traslado insuficiente entre sedes físicas distintas (< 30 min).
6. `INSTRUCTOR_UNAVAILABLE`: Sesión programada durante una excepción/incapacidad activa del docente.

---

### 📊 Contexto 7: `monitoring-service` (Seguimiento Académico y Alertas de Deserción)

#### `FichaTracking`
Cabecera de monitoreo y semáforo de riesgo de una ficha activa.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador del seguimiento de ficha. |
| `ficha_id` | UUID | FK -> `EnrollmentFicha.id`, NOT NULL | Ficha académica bajo supervisión. |
| `risk_status` | ENUM | NOT NULL, DEFAULT 'ON_TRACK' | Semáforo: `ON_TRACK` (Verde), `AT_RISK` (Amarillo), `CRITICAL` (Rojo). |
| `last_calculated_at`| TIMESTAMPTZ| NOT NULL, DEFAULT NOW() | Fecha de última consolidación de KPIs. |

#### `TrackingSession`
Registro de asistencia y bitácora pedagógica diligenciada por el instructor (`PROC_I3`).

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador del registro de clase. |
| `ficha_tracking_id`| UUID| FK -> `FichaTracking.id`, NOT NULL | Cabecera de seguimiento de la ficha. |
| `class_session_id` | UUID | FK -> `ClassSession.id`, NOT NULL | Sesión de clase formativa ejecutada. |
| `instructor_id` | UUID | FK -> `Instructor.id`, NOT NULL | Docente formador que asienta la asistencia. |
| `session_date` | DATE | NOT NULL | Fecha de impartición de la clase. |
| `total_learners` | INTEGER | NOT NULL | Total de aprendices activos matriculados. |
| `attended_learners`| INTEGER | NOT NULL | Aprendices presentes en el aula física. |
| `attendance_rate` | DECIMAL(5,2)| NOT NULL | Porcentaje de asistencia calculado. |
| `pedagogical_notes`| TEXT | NULLABLE | Observaciones sobre el avance curricular y tema. |
| `topic_covered` | VARCHAR(255)| NULLABLE | Tema o evidencia formativa desarrollada. |

#### `GeneratedAlert`
Alerta automática generada ante indicadores de riesgo o baja asistencia.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la alerta. |
| `ficha_tracking_id`| UUID| FK -> `FichaTracking.id`, NOT NULL | Ficha que originó la alerta. |
| `alert_type` | VARCHAR(50) | NOT NULL | Ej: `LOW_ATTENDANCE_RISK` (< 80%), `HOURS_GAP`. |
| `severity` | ENUM | NOT NULL | `CRITICAL`, `HIGH`, `MEDIUM`, `LOW`. |
| `target_role` | ENUM | NOT NULL | Destinatario: `COORDINATOR`, `CENTER_DIRECTOR`, `BIENESTAR`. |
| `message` | TEXT | NOT NULL | Texto explicativo de la condición de riesgo detectada. |
| `is_dismissed` | BOOLEAN | NOT NULL, DEFAULT FALSE | Estado de atención de la alerta. |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Momento de emisión automática. |

---

### 📄 Contexto 8: `document-service` (Plantillas TRD y Documentos PDF)

#### `DocumentTemplate`
Catálogo de formatos oficiales institucionales.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador de la plantilla. |
| `code` | VARCHAR(50) | UNIQUE, NOT NULL | Código TRD: `CONSTANCIA_HORARIO`, `REPORTE_CONFLICTOS`, `SEGUIMIENTO_FICHA`. |
| `name` | VARCHAR(120) | NOT NULL | Nombre oficial del formato documental. |
| `output_format` | VARCHAR(10) | NOT NULL, DEFAULT 'PDF' | Formato de salida generado. |
| `current_version`| INTEGER | NOT NULL, DEFAULT 1 | Versión vigente de la plantilla. |
| `version_status` | ENUM | NOT NULL, DEFAULT 'PUBLISHED'| `PUBLISHED`, `UNDER_REVIEW`, `OBSOLETE`. |
| `is_active` | BOOLEAN | NOT NULL, DEFAULT TRUE | Habilitación en el modal `?modal=generate`. |

#### `GeneratedDocument`
Metadatos de reportes PDF compilados y archivados en el Object Storage.

| Atributo | Tipo | Restricciones | Descripción |
| :--- | :--- | :--- | :--- |
| `id` | UUID | PK | Identificador del documento generado. |
| `template_id` | UUID | FK -> `DocumentTemplate.id`, NOT NULL | Plantilla origen utilizada. |
| `title` | VARCHAR(255) | NOT NULL | Título del documento (ej: Constancia Horario - Ficha 2874412). |
| `domain` | VARCHAR(50) | NOT NULL | Dominio propietario: `scheduling`, `monitoring`, `academic`. |
| `storage_url` | VARCHAR(500) | NULLABLE | URI segura hacia el almacenamiento de objetos S3/Blob. |
| `sha256_hash` | VARCHAR(64) | NULLABLE | Hash inmutable para validación de autenticidad. |
| `version` | INTEGER | NOT NULL, DEFAULT 1 | Número de versión emitida. |
| `generation_status`| ENUM | NOT NULL, DEFAULT 'AVAILABLE'| `AVAILABLE`, `GENERATING`, `GENERATION_FAILED`. |
| `created_by` | UUID | FK -> `User.id`, NULLABLE | Funcionario que solicitó la emisión. |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | Fecha y hora de generación. |

*Invariante*: Los binarios PDF nunca saturan la base de datos relacional; solo se almacena su metadato y `storage_url`.

---

### 🔔 Contexto 9: `notification-service` (Notificaciones Accionables y DeepLinks)

#### `SentNotification`
Mensajería interna y notificaciones Push/Email para actores.

| Atributo | Tipo | Restricciones | PII | Descripción |
| :--- | :--- | :--- | :---: | :--- |
| `id` | UUID | PK | — | Identificador de la notificación. |
| `recipient_user_id`| UUID | FK -> `User.id`, NOT NULL | — | Usuario destinatario. |
| `schedule_id` | UUID | FK -> `Schedule.id`, NULLABLE | — | Horario relacionado (si aplica). |
| `subject` | VARCHAR(150) | NOT NULL | — | Asunto de la alerta (ej: Cambio de ambiente). |
| `summary_message` | TEXT | NOT NULL | — | Cuerpo del mensaje descriptivo. |
| `category` | ENUM | NOT NULL | — | `SCHEDULE_CHANGED`, `SCHEDULE_PUBLISHED`, `GENERAL`. |
| `priority` | ENUM | NOT NULL, DEFAULT 'NORMAL' | — | Prioridad: `HIGH`, `NORMAL`, `LOW`. |
| `deep_link` | VARCHAR(200) | NULLABLE | — | Ruta relativa para redirección directa (ej: `/mi-horario/sesiones/ses-03`). |
| `is_read` | BOOLEAN | NOT NULL, DEFAULT FALSE | — | Bandera de lectura (controla el badge de la barra superior). |
| `delivery_status` | ENUM | NOT NULL, DEFAULT 'SENT' | — | Estado de transporte: `SENT`, `PENDING`, `FAILED`. |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | — | Timestamp de emisión. |

---

### 🛡️ Contexto 10: `audit-service` (Trazabilidad Forense Inmutable ISO 27001)

#### `AuditRecord`
Bitácora inmutable de eventos de seguridad y modificaciones de estado.

| Atributo | Tipo | Restricciones | PII | Descripción |
| :--- | :--- | :--- | :---: | :--- |
| `id` | UUID | PK | — | Identificador de la traza de auditoría. |
| `event_type` | VARCHAR(80) | NOT NULL | — | Evento: `SCHEDULE_PUBLISHED`, `USER_ROLE_ASSIGNED`, `CONFLICT_RESOLVED`. |
| `entity_name` | VARCHAR(50) | NOT NULL | — | Entidad modificada (`schedule`, `user`, `scheduling_conflict`). |
| `entity_id` | VARCHAR(36) | NOT NULL | — | ID de la entidad afectada. |
| `actor_user_id` | UUID | FK -> `User.id`, NULLABLE | — | Usuario que ejecutó la acción (null = sistema). |
| `actor_name` | VARCHAR(100) | NOT NULL | ✓ | Nombre del actor en el momento del evento. |
| `source_service` | VARCHAR(50) | NOT NULL | — | Microservicio origen (`scheduling-service`, `iam-service`). |
| `old_value_json` | JSONB / TEXT | NULLABLE | — | Snapshot del estado previo (JSON). |
| `new_value_json` | JSONB / TEXT | NULLABLE | — | Snapshot del estado resultante (JSON). |
| `outcome` | ENUM | NOT NULL | — | Resultado de la operación: `SUCCESS`, `FAILED`. |
| `ip_address` | VARCHAR(45) | NULLABLE | ✓ | Dirección IP de origen de la solicitud HTTP. |
| `created_at` | TIMESTAMPTZ | NOT NULL, DEFAULT NOW() | — | Timestamp inmutable de registro. |

*Invariante Absoluto*: La tabla `AuditRecord` es de tipo **APPEND-ONLY (Solo INSERT)**. Quedan revocados los permisos de `UPDATE` y `DELETE` para cualquier rol de base de datos.

---

## 4. Matriz de Trazabilidad Total: 12 Procesos BPMN 2.0 vs 10 Bounded Contexts

| Proceso BPMN 2.0 | Rol Actor | Bounded Contexts Primarios | Entidades que Lee / Escribe |
| :--- | :--- | :--- | :--- |
| **`PROC_C1`: Gestión, Validación y Publicación de Horarios** | Coordinador | `scheduling`, `environment`, `actors`, `notification`, `audit` | Escribe `Schedule`, `ClassSession`, `SchedulingConflict`; genera `SentNotification` y `AuditRecord`. |
| **`PROC_C2`: Consulta de Disponibilidad de Recursos** | Coordinador | `environment`, `actors`, `scheduling` | Consulta `Environment`, `EnvironmentType`, `Instructor`, `InstructorException` y `ClassSession`. |
| **`PROC_C3`: Revisión y Aprobación de Excepciones Docentes** | Coordinador | `actors`, `scheduling`, `notification`, `audit` | Actualiza `InstructorException`, reprograma `ClassSession`, genera `SentNotification` y `AuditRecord`. |
| **`PROC_I1`: Consulta de Horario y Registro de Ejecución** | Instructor | `scheduling`, `academic`, `environment` | Lee `ClassSession` y actualiza su estado a `EXECUTED`. |
| **`PROC_I2`: Solicitud de Excepción de Disponibilidad** | Instructor | `actors`, `notification` | Inserta registro en `InstructorException` con adjunto `support_file_url`. |
| **`PROC_I3`: Registro de Seguimiento Académico y Asistencia**| Instructor | `monitoring`, `academic`, `scheduling` | Inserta en `TrackingSession` y dispara `GeneratedAlert` si asistencia < 80%. |
| **`PROC_A1`: Consulta de Horario Propio** | Aprendiz | `scheduling`, `academic`, `environment` | Lee `ClassSession` filtrada por el scope de su `EnrollmentFicha`. |
| **`PROC_A2`: Gestión y Lectura de Notificaciones** | Aprendiz | `notification`, `scheduling` | Lee y actualiza `SentNotification` (`is_read = TRUE`) y navega por `deep_link`. |
| **`PROC_D1`: Monitoreo Directivo y KPIs de Deserción** | Director | `monitoring`, `academic`, `scheduling` | Agrega métricas desde `TrackingSession`, `FichaTracking` y gestiona `GeneratedAlert`. |
| **`PROC_D2`: Gestión de Identidades y Matriz RBAC** | Director | `iam`, `reference-data`, `audit` | Administra `User` y asigna `UserRole` contextualizado en `CampusSede`. |
| **`PROC_S1`: Generación y Gestión Documental** | Soporte | `document`, `scheduling`, `monitoring` | Lee `DocumentTemplate` y emite `GeneratedDocument` (PDF/SHA-256). |
| **`PROC_S2`: Trazabilidad, Logs y Auditoría** | Soporte / Auditor | `audit`, `iam` | Consulta `AuditRecord` y visualiza diff JSON old vs new en modal `?modal=audit`. |

---

## 5. Patrones de Acceso y Queries Críticos (Target Latency)

| Query / Operación de Negocio | Microservicio Propietario | Frecuencia | Latencia Objetivo | Mecanismo de Optimización |
| :--- | :--- | :--- | :---: | :--- |
| **Validación de Cruces y Traslados de Horario** | `scheduling-service` | Alta (en editor) | < 250 ms | Índices compuestos `(instructor_id, day_of_week, specific_date)` y `(environment_id, day_of_week)`. |
| **Matriz Semanal de Disponibilidad de Aula** | `training-environment-service` | Muy Alta | < 100 ms | Cache en Redis de matriz de ocupación por semana. |
| **Carga de Agenda Semanal del Docente** | `scheduling-service` | Alta (al loguear) | < 150 ms | Índice en `ClassSession(instructor_id, specific_date)`. |
| **Cálculo de Deserción y Semáforo de Fichas** | `monitoring-service` | Media (Dashboard)| < 300 ms | Agregación precomputada en `FichaTracking`. |
| **Resolución de Permisos y Scopes RBAC** | `iam-service` | En cada request | < 10 ms | Token JWT firmado con claims y roles embebidos. |
| **Inspección Forense de Diff de Auditoría** | `audit-service` | Baja (auditoría) | < 500 ms | Almacenamiento JSONB indexado por `(entity_name, entity_id)`. |

---

## 6. Políticas de Retención y Protección de Datos (PII / Habeas Data)

* **Datos de Fichas y Matrículas (`EnrollmentFicha`, `LearnerEnrollment`)**: Retención obligatoria de **10 años** post-certificación según normativa archivística del SENA.
* **Trazas de Auditoría (`AuditRecord`)**: Retención inmutable de **7 años** bajo estándar ISO/IEC 27001 y control fiscal de la Contraloría.
* **Datos Personales e Identidades PII (`User`, `Instructor`, `Learner`)**: Conservación durante la relación contractual/académica y hasta **5 años** post-desvinculación para fines de expedición de certificados.
* **Logs de Acceso e Intentos de Login**: Depuración automática programada de registros mayores a **90 días**.